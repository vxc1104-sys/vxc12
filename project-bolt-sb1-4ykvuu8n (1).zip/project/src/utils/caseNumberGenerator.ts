export interface CaseNumberConfig {
  case_type: 'booking' | 'quotation';
  direction: 'import' | 'export';
}

export const generateCaseNumber = async (
  config: CaseNumberConfig,
  getLastSequenceNumber: (prefix: string, year: number, month: number) => Promise<number>
): Promise<string> => {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  
  // Generate prefix based on type and direction
  let prefix = 'H'; // Hamburg
  
  if (config.case_type === 'booking') {
    prefix += config.direction === 'export' ? 'BE' : 'BI';
  } else {
    prefix += config.direction === 'export' ? 'QE' : 'QI';
  }
  
  // Get the last sequence number for this prefix/year/month combination
  const lastSequence = await getLastSequenceNumber(prefix, year, month);
  const nextSequence = lastSequence + 1;
  
  // Format components
  const yearStr = year.toString().slice(-2);
  const monthStr = month.toString().padStart(2, '0');
  const sequenceStr = nextSequence.toString().padStart(4, '0');
  
  return `${prefix} ${yearStr} ${monthStr} ${sequenceStr}`;
};

export const parseCaseNumber = (caseNumber: string) => {
  const parts = caseNumber.split(' ');
  if (parts.length !== 4) {
    throw new Error('Invalid case number format');
  }
  
  const [prefix, year, month, sequence] = parts;
  
  // Parse prefix
  const location = prefix.charAt(0); // H for Hamburg
  const typeAndDirection = prefix.slice(1);
  
  let case_type: 'booking' | 'quotation';
  let direction: 'import' | 'export';
  
  switch (typeAndDirection) {
    case 'BE':
      case_type = 'booking';
      direction = 'export';
      break;
    case 'BI':
      case_type = 'booking';
      direction = 'import';
      break;
    case 'QE':
      case_type = 'quotation';
      direction = 'export';
      break;
    case 'QI':
      case_type = 'quotation';
      direction = 'import';
      break;
    default:
      throw new Error('Invalid case number prefix');
  }
  
  return {
    location,
    case_type,
    direction,
    year: parseInt(`20${year}`),
    month: parseInt(month),
    sequence: parseInt(sequence)
  };
};