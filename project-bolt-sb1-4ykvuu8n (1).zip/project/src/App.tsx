import React, { useState, useEffect } from 'react';
import WindowManager from './components/WindowManager';
import MainApplication from './components/MainApplication';
import { supabase } from './lib/supabase';

function App() {
  return (
    <WindowManager>
      <MainApplication />
    </WindowManager>
  );
}

export default App;