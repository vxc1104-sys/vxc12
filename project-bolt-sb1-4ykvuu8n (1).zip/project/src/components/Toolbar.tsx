import React, { useState } from 'react';
import { Plus, Save, Copy, RowsIcon, Trash2, Search, CheckCircle } from 'lucide-react';

interface ToolbarProps {
  onNewCase: () => void;
  onCopyCase: () => void;
  onDeleteCase: () => void;
  onSearch: (query: string) => void;
  selectedCaseId: string | null;
  autoSaveStatus: 'idle' | 'saving' | 'saved';
}

const Toolbar: React.FC<ToolbarProps> = ({
  onNewCase,
  onCopyCase,
  onDeleteCase,
  onSearch,
  selectedCaseId,
  autoSaveStatus
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    onSearch(query);
  };

  return (
    <div className="bg-white border-b border-gray-300 px-4 py-2 flex items-center justify-between shadow-sm">
      {/* Left side - Action buttons */}
      <div className="flex items-center space-x-2">
        <button
          onClick={onNewCase}
          className="flex items-center px-3 py-1.5 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4 mr-1" />
          New Case
        </button>

        <div className="w-px h-6 bg-gray-300" />

        <button
          onClick={onCopyCase}
          disabled={!selectedCaseId}
          className="flex items-center px-3 py-1.5 bg-gray-100 text-gray-700 rounded text-sm hover:bg-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Copy className="w-4 h-4 mr-1" />
          Copy
        </button>

        <button
          className="flex items-center px-3 py-1.5 bg-gray-100 text-gray-700 rounded text-sm hover:bg-gray-200 transition-colors"
        >
          <RowsIcon className="w-4 h-4 mr-1" />
          Append
        </button>

        <button
          onClick={onDeleteCase}
          disabled={!selectedCaseId}
          className="flex items-center px-3 py-1.5 bg-red-100 text-red-700 rounded text-sm hover:bg-red-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Trash2 className="w-4 h-4 mr-1" />
          Delete
        </button>
      </div>

      {/* Center - Auto-save status */}
      <div className="flex items-center space-x-2">
        {autoSaveStatus === 'saving' && (
          <div className="flex items-center text-sm text-blue-600">
            <div className="animate-spin w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full mr-2"></div>
            Saving...
          </div>
        )}
        {autoSaveStatus === 'saved' && (
          <div className="flex items-center text-sm text-green-600">
            <CheckCircle className="w-4 h-4 mr-2" />
            All changes saved
          </div>
        )}
      </div>

      {/* Right side - Search */}
      <div className="flex items-center space-x-2">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={handleSearchChange}
            placeholder="Search by case number..."
            className="pl-10 pr-4 py-1.5 border border-gray-300 rounded text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 w-64"
          />
        </div>
      </div>
    </div>
  );
};

export default Toolbar;