import React, { useState, useEffect } from 'react';
import Toolbar from './Toolbar';
import SidebarFilters, { FilterState } from './SidebarFilters';
import CaseExplorerGrid from './CaseExplorerGrid';
import NewCaseModal from './NewCaseModal';
import { supabase } from '../lib/supabase';
import { generateCaseNumber } from '../utils/caseNumberGenerator';
import { useAutoSave } from '../hooks/useAutoSave';
import { FileText } from 'lucide-react';

interface Case {
  id: string;
  case_number: string;
  case_type: string;
  status: string;
  reference: string | null;
  direction: string;
  customer?: {
    name: string;
    contact_person: string | null;
  };
  created_at: string;
  departure_date: string | null;
  arrival_date: string | null;
}

interface MainApplicationProps {
  openCaseWindow?: (caseId: string, caseNumber: string) => void;
}

const MainApplication: React.FC<MainApplicationProps> = ({ openCaseWindow }) => {
  const [cases, setCases] = useState<Case[]>([]);
  const [selectedCase, setSelectedCase] = useState<Case | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [showNewCaseModal, setShowNewCaseModal] = useState(false);
  const [filters, setFilters] = useState<FilterState>({
    direction: 'all',
    type: 'all',
    status: 'all',
    dateRange: 'all'
  });

  const { status: autoSaveStatus, triggerSave } = useAutoSave({
    onSave: async () => {
      console.log('Auto-saving changes...');
    }
  });

  useEffect(() => {
    fetchCases();
  }, []);

  const fetchCases = async () => {
    try {
      const { data, error } = await supabase
        .from('cases')
        .select(`
          *,
          customers (
            name,
            contact_person
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCases(data || []);
    } catch (error) {
      console.error('Error fetching cases:', error);
    } finally {
      setLoading(false);
    }
  };

  const getLastSequenceNumber = async (prefix: string, year: number, month: number): Promise<number> => {
    try {
      const { data, error } = await supabase
        .from('cases')
        .select('case_number')
        .like('case_number', `${prefix} ${year.toString().slice(-2)} ${month.toString().padStart(2, '0')}%`)
        .order('case_number', { ascending: false })
        .limit(1);

      if (error) throw error;
      
      if (data && data.length > 0) {
        const lastCaseNumber = data[0].case_number;
        const parts = lastCaseNumber.split(' ');
        return parseInt(parts[3]) || 0;
      }
      
      return 0;
    } catch (error) {
      console.error('Error getting last sequence number:', error);
      return 0;
    }
  };

  const handleNewCase = async (caseData: {
    case_type: string;
    direction: string;
    customer_id?: string;
    reference?: string;
  }) => {
    try {
      const caseNumber = await generateCaseNumber(
        {
          case_type: caseData.case_type as 'booking' | 'quotation',
          direction: caseData.direction as 'import' | 'export'
        },
        getLastSequenceNumber
      );

      const newCase = {
        case_number: caseNumber,
        case_type: caseData.case_type,
        direction: caseData.direction,
        customer_id: caseData.customer_id || null,
        reference: caseData.reference || null,
        status: 'draft'
      };

      const { data, error } = await supabase
        .from('cases')
        .insert([newCase])
        .select(`
          *,
          customers (
            name,
            contact_person
          )
        `)
        .single();

      if (error) throw error;
      
      setCases([data, ...cases]);
      setSelectedCase(data);
      
      // Open the new case in a window
      if (openCaseWindow) {
        openCaseWindow(data.id, data.case_number);
      }
      
      triggerSave();
    } catch (error) {
      console.error('Error creating case:', error);
    }
  };

  const handleCopyCase = async () => {
    if (!selectedCase) return;
    
    try {
      const caseNumber = await generateCaseNumber(
        {
          case_type: selectedCase.case_type as 'booking' | 'quotation',
          direction: (selectedCase.direction || 'export') as 'import' | 'export'
        },
        getLastSequenceNumber
      );

      const { data, error } = await supabase
        .from('cases')
        .insert([{
          case_number: caseNumber,
          case_type: selectedCase.case_type,
          direction: selectedCase.direction,
          customer_id: selectedCase.customer?.name ? null : null,
          reference: `Copy of ${selectedCase.reference || selectedCase.case_number}`,
          status: 'draft'
        }])
        .select(`
          *,
          customers (
            name,
            contact_person
          )
        `)
        .single();

      if (error) throw error;
      
      setCases([data, ...cases]);
      setSelectedCase(data);
      
      // Open the copied case in a window
      if (openCaseWindow) {
        openCaseWindow(data.id, data.case_number);
      }
      
      triggerSave();
    } catch (error) {
      console.error('Error copying case:', error);
    }
  };

  const handleDeleteCase = async () => {
    if (!selectedCase) return;
    
    if (confirm(`Are you sure you want to delete case ${selectedCase.case_number}?`)) {
      try {
        const { error } = await supabase
          .from('cases')
          .delete()
          .eq('id', selectedCase.id);

        if (error) throw error;
        
        setCases(cases.filter(c => c.id !== selectedCase.id));
        setSelectedCase(null);
        triggerSave();
      } catch (error) {
        console.error('Error deleting case:', error);
      }
    }
  };

  const filteredCases = cases.filter(caseItem => {
    if (searchQuery && !caseItem.case_number.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }

    if (filters.direction !== 'all') {
      const caseDirection = caseItem.case_number.includes('I') ? 'import' : 'export';
      if (caseDirection !== filters.direction) return false;
    }

    if (filters.type !== 'all' && caseItem.case_type !== filters.type) {
      return false;
    }

    if (filters.status !== 'all' && caseItem.status !== filters.status) {
      return false;
    }

    if (filters.dateRange !== 'all') {
      const caseDate = new Date(caseItem.created_at);
      const now = new Date();
      
      switch (filters.dateRange) {
        case 'today':
          if (caseDate.toDateString() !== now.toDateString()) return false;
          break;
        case 'week':
          const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          if (caseDate < weekAgo) return false;
          break;
        case 'month':
          if (caseDate.getMonth() !== now.getMonth() || caseDate.getFullYear() !== now.getFullYear()) return false;
          break;
        case 'year':
          if (caseDate.getFullYear() !== now.getFullYear()) return false;
          break;
      }
    }

    return true;
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading cases...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      {/* Top Toolbar */}
      <Toolbar
        onNewCase={() => setShowNewCaseModal(true)}
        onCopyCase={handleCopyCase}
        onDeleteCase={handleDeleteCase}
        onSearch={setSearchQuery}
        selectedCaseId={selectedCase?.id || null}
        autoSaveStatus={autoSaveStatus}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex">
        {/* Left Sidebar - Filters */}
        <SidebarFilters
          filters={filters}
          onFiltersChange={setFilters}
          caseCount={filteredCases.length}
        />

        {/* Center - Case Explorer */}
        <div className="flex-1 flex flex-col">
          {/* Case List Header */}
          <div className="bg-white border-b border-gray-200 px-4 py-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <h1 className="text-lg font-semibold text-gray-900">MOVE Logistics</h1>
                {selectedCase && (
                  <div className="text-sm text-gray-600">
                    <span className="font-medium">{selectedCase.case_number}</span>
                    {selectedCase.customer && (
                      <span className="ml-2">- {selectedCase.customer.name}</span>
                    )}
                  </div>
                )}
              </div>
              
              {selectedCase && (
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    selectedCase.status === 'active' ? 'bg-green-100 text-green-800' :
                    selectedCase.status === 'draft' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {selectedCase.status.toUpperCase()}
                  </span>
                  
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    selectedCase.case_type === 'booking' ? 'bg-blue-100 text-blue-800' :
                    'bg-purple-100 text-purple-800'
                  }`}>
                    {selectedCase.case_type.toUpperCase()}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Case Explorer Grid */}
          <CaseExplorerGrid
            cases={filteredCases}
            selectedCaseId={selectedCase?.id || null}
            onCaseSelect={setSelectedCase}
            onCaseDoubleClick={(caseData) => {
              setSelectedCase(caseData);
              if (openCaseWindow) {
                openCaseWindow(caseData.id, caseData.case_number);
              }
            }}
          />
        </div>

        {/* Right Panel - Instructions */}
        <div className="w-96 border-l border-gray-200 bg-white">
          <div className="p-6">
            <div className="text-center">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Case Window System</h3>
              <p className="text-gray-500 mb-4">
                Double-click any case to open it in a separate window with full editing capabilities.
              </p>
              <div className="text-sm text-gray-600 space-y-2">
                <p>• Each case opens in its own window</p>
                <p>• Multiple cases can be open simultaneously</p>
                <p>• All changes are auto-saved</p>
                <p>• Windows can be minimized, maximized, and moved</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* New Case Modal */}
      <NewCaseModal
        isOpen={showNewCaseModal}
        onClose={() => setShowNewCaseModal(false)}
        onCreateCase={handleNewCase}
      />
    </div>
  );
};

export default MainApplication;