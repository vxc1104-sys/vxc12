import React, { useState, useCallback } from 'react';
import CaseWindow from './CaseWindow';
import { NavigationSection } from './NavigationMenu';

interface OpenWindow {
  id: string;
  caseId: string;
  caseNumber: string;
  initialSection?: NavigationSection;
}

interface WindowManagerProps {
  children: React.ReactNode;
}

const WindowManager: React.FC<WindowManagerProps> = ({ children }) => {
  const [openWindows, setOpenWindows] = useState<OpenWindow[]>([]);

  const openCaseWindow = useCallback((caseId: string, caseNumber: string, initialSection?: NavigationSection) => {
    const windowId = `case-${caseId}`;
    
    // Check if window is already open
    const existingWindow = openWindows.find(w => w.id === windowId);
    if (existingWindow) {
      // Window already open, just focus it (in a real implementation)
      return;
    }

    // Add new window
    setOpenWindows(prev => [...prev, {
      id: windowId,
      caseId,
      caseNumber,
      initialSection
    }]);
  }, [openWindows]);

  const closeCaseWindow = useCallback((windowId: string) => {
    setOpenWindows(prev => prev.filter(w => w.id !== windowId));
  }, []);

  // Provide the openCaseWindow function to child components via context or props
  const childrenWithProps = React.Children.map(children, child => {
    if (React.isValidElement(child)) {
      return React.cloneElement(child, { openCaseWindow } as any);
    }
    return child;
  });

  return (
    <>
      {childrenWithProps}
      
      {/* Render all open case windows */}
      {openWindows.map(window => (
        <CaseWindow
          key={window.id}
          caseId={window.caseId}
          caseNumber={window.caseNumber}
          initialSection={window.initialSection}
          onClose={() => closeCaseWindow(window.id)}
        />
      ))}
    </>
  );
};

export default WindowManager;