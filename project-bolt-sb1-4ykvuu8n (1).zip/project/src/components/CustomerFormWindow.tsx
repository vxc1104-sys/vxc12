import React, { useState, useEffect } from 'react';
import { X, Save, User, MapPin, Phone, Mail, Globe, Clock, FileText } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Customer {
  id?: string;
  company_name: string;
  customer_code: string;
  address_line1: string;
  address_line2: string;
  city: string;
  postal_code: string;
  country: string;
  contact_person_primary: string;
  contact_person_secondary: string;
  phone_primary: string;
  phone_secondary: string;
  email_primary: string;
  email_secondary: string;
  website: string;
  opening_hours: string;
  internal_notes: string;
}

interface CustomerFormWindowProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (customer: Customer) => void;
  initialCustomer?: Customer | null;
}

const CustomerFormWindow: React.FC<CustomerFormWindowProps> = ({
  isOpen,
  onClose,
  onSave,
  initialCustomer
}) => {
  const [customer, setCustomer] = useState<Customer>({
    company_name: '',
    customer_code: '',
    address_line1: '',
    address_line2: '',
    city: '',
    postal_code: '',
    country: '',
    contact_person_primary: '',
    contact_person_secondary: '',
    phone_primary: '',
    phone_secondary: '',
    email_primary: '',
    email_secondary: '',
    website: '',
    opening_hours: '',
    internal_notes: ''
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (initialCustomer) {
      setCustomer(initialCustomer);
    } else {
      // Reset form for new customer
      setCustomer({
        company_name: '',
        customer_code: '',
        address_line1: '',
        address_line2: '',
        city: '',
        postal_code: '',
        country: '',
        contact_person_primary: '',
        contact_person_secondary: '',
        phone_primary: '',
        phone_secondary: '',
        email_primary: '',
        email_secondary: '',
        website: '',
        opening_hours: '',
        internal_notes: ''
      });
    }
  }, [initialCustomer, isOpen]);

  const handleFieldChange = (field: keyof Customer, value: string) => {
    setCustomer(prev => ({ ...prev, [field]: value }));
  };

  const generateCustomerCode = (companyName: string) => {
    // Generate a customer code from company name
    const words = companyName.toUpperCase().split(' ');
    if (words.length >= 2) {
      return words[0].substring(0, 3) + words[1].substring(0, 3);
    }
    return companyName.toUpperCase().substring(0, 6);
  };

  const handleCompanyNameChange = (value: string) => {
    handleFieldChange('company_name', value);
    if (!customer.customer_code && value) {
      handleFieldChange('customer_code', generateCustomerCode(value));
    }
  };

  const handleSave = async () => {
    if (!customer.company_name.trim()) {
      alert('Company name is required');
      return;
    }

    setSaving(true);
    try {
      let savedCustomer;
      
      if (customer.id) {
        // Update existing customer
        const { data, error } = await supabase
          .from('customers')
          .update({
            company_name: customer.company_name,
            customer_code: customer.customer_code,
            address_line1: customer.address_line1,
            address_line2: customer.address_line2,
            city: customer.city,
            postal_code: customer.postal_code,
            country: customer.country,
            contact_person_primary: customer.contact_person_primary,
            contact_person_secondary: customer.contact_person_secondary,
            phone_primary: customer.phone_primary,
            phone_secondary: customer.phone_secondary,
            email_primary: customer.email_primary,
            email_secondary: customer.email_secondary,
            website: customer.website,
            opening_hours: customer.opening_hours,
            internal_notes: customer.internal_notes,
            updated_at: new Date().toISOString()
          })
          .eq('id', customer.id)
          .select()
          .single();

        if (error) throw error;
        savedCustomer = data;
      } else {
        // Create new customer
        const { data, error } = await supabase
          .from('customers')
          .insert([{
            company_name: customer.company_name,
            customer_code: customer.customer_code,
            address_line1: customer.address_line1,
            address_line2: customer.address_line2,
            city: customer.city,
            postal_code: customer.postal_code,
            country: customer.country,
            contact_person_primary: customer.contact_person_primary,
            contact_person_secondary: customer.contact_person_secondary,
            phone_primary: customer.phone_primary,
            phone_secondary: customer.phone_secondary,
            email_primary: customer.email_primary,
            email_secondary: customer.email_secondary,
            website: customer.website,
            opening_hours: customer.opening_hours,
            internal_notes: customer.internal_notes
          }])
          .select()
          .single();

        if (error) throw error;
        savedCustomer = data;
      }

      onSave(savedCustomer);
      onClose();
    } catch (error) {
      console.error('Error saving customer:', error);
      alert('Error saving customer. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-4xl mx-4 max-h-[90vh] overflow-hidden">
        {/* Window Title Bar */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <User className="w-5 h-5" />
            <span className="font-medium">
              {customer.id ? 'Edit Customer' : 'New Customer'}
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-6 bg-red-500 hover:bg-red-600 rounded flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
          <div className="grid grid-cols-2 gap-8">
            {/* Left Column - Basic Information */}
            <div className="space-y-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-sm font-semibold text-blue-800 mb-4 flex items-center">
                  <User className="w-4 h-4 mr-2" />
                  Company Information
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Company Name *
                    </label>
                    <input
                      type="text"
                      value={customer.company_name}
                      onChange={(e) => handleCompanyNameChange(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="e.g., Rossmann GmbH"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Customer Code
                    </label>
                    <input
                      type="text"
                      value={customer.customer_code}
                      onChange={(e) => handleFieldChange('customer_code', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="e.g., ROSGMB"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="text-sm font-semibold text-green-800 mb-4 flex items-center">
                  <MapPin className="w-4 h-4 mr-2" />
                  Address
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Address Line 1
                    </label>
                    <input
                      type="text"
                      value={customer.address_line1}
                      onChange={(e) => handleFieldChange('address_line1', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-green-500 focus:border-green-500"
                      placeholder="Street and number"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Address Line 2
                    </label>
                    <input
                      type="text"
                      value={customer.address_line2}
                      onChange={(e) => handleFieldChange('address_line2', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-green-500 focus:border-green-500"
                      placeholder="Additional address info"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Postal Code
                      </label>
                      <input
                        type="text"
                        value={customer.postal_code}
                        onChange={(e) => handleFieldChange('postal_code', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-green-500 focus:border-green-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        City
                      </label>
                      <input
                        type="text"
                        value={customer.city}
                        onChange={(e) => handleFieldChange('city', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-green-500 focus:border-green-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Country
                    </label>
                    <input
                      type="text"
                      value={customer.country}
                      onChange={(e) => handleFieldChange('country', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - Contact Information */}
            <div className="space-y-6">
              <div className="bg-purple-50 p-4 rounded-lg">
                <h3 className="text-sm font-semibold text-purple-800 mb-4 flex items-center">
                  <Phone className="w-4 h-4 mr-2" />
                  Contact Information
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Primary Contact Person
                    </label>
                    <input
                      type="text"
                      value={customer.contact_person_primary}
                      onChange={(e) => handleFieldChange('contact_person_primary', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Secondary Contact Person
                    </label>
                    <input
                      type="text"
                      value={customer.contact_person_secondary}
                      onChange={(e) => handleFieldChange('contact_person_secondary', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Primary Phone
                      </label>
                      <input
                        type="tel"
                        value={customer.phone_primary}
                        onChange={(e) => handleFieldChange('phone_primary', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Secondary Phone
                      </label>
                      <input
                        type="tel"
                        value={customer.phone_secondary}
                        onChange={(e) => handleFieldChange('phone_secondary', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Primary Email
                      </label>
                      <input
                        type="email"
                        value={customer.email_primary}
                        onChange={(e) => handleFieldChange('email_primary', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Secondary Email
                      </label>
                      <input
                        type="email"
                        value={customer.email_secondary}
                        onChange={(e) => handleFieldChange('email_secondary', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                      <Globe className="w-4 h-4 mr-1" />
                      Website
                    </label>
                    <input
                      type="url"
                      value={customer.website}
                      onChange={(e) => handleFieldChange('website', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      placeholder="https://www.example.com"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-yellow-50 p-4 rounded-lg">
                <h3 className="text-sm font-semibold text-yellow-800 mb-4 flex items-center">
                  <Clock className="w-4 h-4 mr-2" />
                  Additional Information
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Opening Hours
                    </label>
                    <input
                      type="text"
                      value={customer.opening_hours}
                      onChange={(e) => handleFieldChange('opening_hours', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500"
                      placeholder="e.g., Mon-Fri 9:00-17:00"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                      <FileText className="w-4 h-4 mr-1" />
                      Internal Notes
                    </label>
                    <textarea
                      value={customer.internal_notes}
                      onChange={(e) => handleFieldChange('internal_notes', e.target.value)}
                      rows={4}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 resize-none"
                      placeholder="Internal notes and comments..."
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-gray-50 px-6 py-4 flex items-center justify-end space-x-3 border-t">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-700 bg-gray-200 rounded hover:bg-gray-300 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving || !customer.company_name.trim()}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Save className="w-4 h-4 mr-2" />
            {saving ? 'Saving...' : 'Save Customer'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CustomerFormWindow;