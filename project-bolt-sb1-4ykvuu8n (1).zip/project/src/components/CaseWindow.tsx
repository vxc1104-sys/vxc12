import React, { useState, useEffect, useRef } from 'react';
import { X, Minus, Square, Copy } from 'lucide-react';
import NavigationMenu, { NavigationSection } from './NavigationMenu';
import OverviewSection from './sections/OverviewSection';
import GoodsSection from './sections/GoodsSection';
import RouteSection from './sections/RouteSection';
import FinanceSection from './sections/FinanceSection';
import DocumentsSection from './sections/DocumentsSection';
import HistorySection from './sections/HistorySection';
import SettingsSection from './sections/SettingsSection';

interface CaseWindowProps {
  caseId: string;
  caseNumber: string;
  onClose: () => void;
  initialSection?: NavigationSection;
}

const CaseWindow: React.FC<CaseWindowProps> = ({
  caseId,
  caseNumber,
  onClose,
  initialSection = 'overview'
}) => {
  const [activeSection, setActiveSection] = useState<NavigationSection>(initialSection);
  const [isMaximized, setIsMaximized] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [position, setPosition] = useState({ x: 100, y: 100 });
  const [size, setSize] = useState({ width: 1200, height: 800 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const windowRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Set window title
    document.title = `${caseNumber} - MOVE Logistics`;
    
    // Cleanup on unmount
    return () => {
      document.title = 'VXC Logistics';
    };
  }, [caseNumber]);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (isMaximized) return;
    
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - position.x,
      y: e.clientY - position.y
    });
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging || isMaximized) return;
    
    setPosition({
      x: e.clientX - dragOffset.x,
      y: e.clientY - dragOffset.y
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, dragOffset]);

  const handleMinimize = () => {
    setIsMinimized(!isMinimized);
  };

  const handleMaximize = () => {
    setIsMaximized(!isMaximized);
  };

  const renderSection = () => {
    switch (activeSection) {
      case 'overview':
        return <OverviewSection caseId={caseId} />;
      case 'goods':
        return <GoodsSection caseId={caseId} />;
      case 'route':
        return <RouteSection caseId={caseId} />;
      case 'finance':
        return <FinanceSection caseId={caseId} />;
      case 'documents':
        return <DocumentsSection caseId={caseId} />;
      case 'history':
        return <HistorySection caseId={caseId} />;
      case 'settings':
        return <SettingsSection caseId={caseId} />;
      default:
        return <OverviewSection caseId={caseId} />;
    }
  };

  const windowStyle = isMaximized
    ? {
        position: 'fixed' as const,
        top: 0,
        left: 0,
        width: '100vw',
        height: '100vh',
        zIndex: 1000
      }
    : {
        position: 'fixed' as const,
        top: position.y,
        left: position.x,
        width: size.width,
        height: size.height,
        zIndex: 1000
      };

  if (isMinimized) {
    return (
      <div
        className="fixed bottom-4 left-4 bg-white border border-gray-300 rounded shadow-lg p-2 cursor-pointer z-50"
        onClick={handleMinimize}
      >
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-blue-500 rounded"></div>
          <span className="text-sm font-medium">{caseNumber}</span>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={windowRef}
      className="bg-white border border-gray-400 rounded-lg shadow-2xl overflow-hidden"
      style={windowStyle}
    >
      {/* Window Title Bar */}
      <div
        className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-2 flex items-center justify-between cursor-move select-none"
        onMouseDown={handleMouseDown}
      >
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-white bg-opacity-20 rounded"></div>
          <span className="font-medium">{caseNumber} - MOVE Logistics</span>
        </div>
        
        <div className="flex items-center space-x-1">
          <button
            onClick={handleMinimize}
            className="w-8 h-6 bg-white bg-opacity-20 hover:bg-opacity-30 rounded flex items-center justify-center transition-colors"
          >
            <Minus className="w-3 h-3" />
          </button>
          
          <button
            onClick={handleMaximize}
            className="w-8 h-6 bg-white bg-opacity-20 hover:bg-opacity-30 rounded flex items-center justify-center transition-colors"
          >
            {isMaximized ? <Copy className="w-3 h-3" /> : <Square className="w-3 h-3" />}
          </button>
          
          <button
            onClick={onClose}
            className="w-8 h-6 bg-red-500 hover:bg-red-600 rounded flex items-center justify-center transition-colors"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Window Content */}
      <div className="flex h-full" style={{ height: 'calc(100% - 40px)' }}>
        {/* Left Navigation */}
        <NavigationMenu
          activeSection={activeSection}
          onSectionChange={setActiveSection}
        />

        {/* Right Content Panel */}
        <div className="flex-1 overflow-hidden">
          {renderSection()}
        </div>
      </div>
    </div>
  );
};

export default CaseWindow;