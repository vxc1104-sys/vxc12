import React from 'react';
import { FileText, Package, Ship, Calendar, User, MapPin } from 'lucide-react';

interface Case {
  id: string;
  case_number: string;
  case_type: string;
  status: string;
  reference: string | null;
  customer?: {
    name: string;
    contact_person: string | null;
  };
  created_at: string;
  departure_date: string | null;
  arrival_date: string | null;
}

interface CaseExplorerGridProps {
  cases: Case[];
  selectedCaseId: string | null;
  onCaseSelect: (caseData: Case) => void;
  onCaseDoubleClick: (caseData: Case) => void;
}

const CaseExplorerGrid: React.FC<CaseExplorerGridProps> = ({
  cases,
  selectedCaseId,
  onCaseSelect,
  onCaseDoubleClick
}) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'draft':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'completed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'booking':
        return <Ship className="w-4 h-4" />;
      case 'quotation':
        return <FileText className="w-4 h-4" />;
      default:
        return <Package className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'booking':
        return 'text-blue-600';
      case 'quotation':
        return 'text-purple-600';
      default:
        return 'text-gray-600';
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleDateString('de-DE', {
      day: '2-digit',
      month: '2-digit',
      year: '2-digit'
    });
  };

  if (cases.length === 0) {
    return (
      <div className="flex-1 bg-white flex items-center justify-center">
        <div className="text-center">
          <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Cases Found</h3>
          <p className="text-gray-500">Create a new case or adjust your filters</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 bg-white overflow-hidden">
      {/* Header */}
      <div className="bg-gray-50 border-b border-gray-200 px-4 py-2">
        <div className="grid grid-cols-12 gap-4 text-xs font-medium text-gray-600 uppercase tracking-wide">
          <div className="col-span-2">Case Number</div>
          <div className="col-span-1">Type</div>
          <div className="col-span-2">Customer</div>
          <div className="col-span-2">Reference</div>
          <div className="col-span-1">Status</div>
          <div className="col-span-1">Created</div>
          <div className="col-span-1">ETD</div>
          <div className="col-span-1">ETA</div>
          <div className="col-span-1">Contact</div>
        </div>
      </div>

      {/* Cases List */}
      <div className="overflow-y-auto h-full">
        {cases.map((caseItem, index) => (
          <div
            key={caseItem.id}
            className={`grid grid-cols-12 gap-4 px-4 py-3 border-b border-gray-100 cursor-pointer hover:bg-blue-50 transition-colors ${
              selectedCaseId === caseItem.id ? 'bg-blue-100 border-blue-200' : ''
            } ${index % 2 === 0 ? 'bg-white' : 'bg-gray-25'}`}
            onClick={() => onCaseSelect(caseItem)}
            onDoubleClick={() => onCaseDoubleClick(caseItem)}
          >
            {/* Case Number */}
            <div className="col-span-2 flex items-center">
              <div className={`mr-2 ${getTypeColor(caseItem.case_type)}`}>
                {getTypeIcon(caseItem.case_type)}
              </div>
              <div>
                <div className="font-medium text-gray-900 text-sm">
                  {caseItem.case_number}
                </div>
              </div>
            </div>

            {/* Type */}
            <div className="col-span-1 flex items-center">
              <span className={`px-2 py-1 text-xs rounded-full border ${
                caseItem.case_type === 'booking' 
                  ? 'bg-blue-50 text-blue-700 border-blue-200'
                  : 'bg-purple-50 text-purple-700 border-purple-200'
              }`}>
                {caseItem.case_type.charAt(0).toUpperCase() + caseItem.case_type.slice(1)}
              </span>
            </div>

            {/* Customer */}
            <div className="col-span-2 flex items-center">
              <User className="w-3 h-3 mr-1 text-gray-400" />
              <div className="truncate">
                <div className="text-sm font-medium text-gray-900 truncate">
                  {caseItem.customer?.name || 'No Customer'}
                </div>
              </div>
            </div>

            {/* Reference */}
            <div className="col-span-2 flex items-center">
              <div className="text-sm text-gray-600 truncate">
                {caseItem.reference || '-'}
              </div>
            </div>

            {/* Status */}
            <div className="col-span-1 flex items-center">
              <span className={`px-2 py-1 text-xs rounded-full border ${getStatusColor(caseItem.status)}`}>
                {caseItem.status.charAt(0).toUpperCase() + caseItem.status.slice(1)}
              </span>
            </div>

            {/* Created Date */}
            <div className="col-span-1 flex items-center">
              <Calendar className="w-3 h-3 mr-1 text-gray-400" />
              <span className="text-sm text-gray-600">
                {formatDate(caseItem.created_at)}
              </span>
            </div>

            {/* ETD */}
            <div className="col-span-1 flex items-center">
              <span className="text-sm text-gray-600">
                {formatDate(caseItem.departure_date)}
              </span>
            </div>

            {/* ETA */}
            <div className="col-span-1 flex items-center">
              <span className="text-sm text-gray-600">
                {formatDate(caseItem.arrival_date)}
              </span>
            </div>

            {/* Contact */}
            <div className="col-span-1 flex items-center">
              <div className="text-sm text-gray-600 truncate">
                {caseItem.customer?.contact_person || '-'}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CaseExplorerGrid;