import React, { useState } from 'react';
import { X, FileText, Ship } from 'lucide-react';

interface NewCaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateCase: (caseData: {
    case_type: string;
    direction: string;
    customer_id?: string;
    reference?: string;
  }) => void;
}

const NewCaseModal: React.FC<NewCaseModalProps> = ({
  isOpen,
  onClose,
  onCreateCase
}) => {
  const [caseType, setCaseType] = useState<'booking' | 'quotation'>('booking');
  const [direction, setDirection] = useState<'import' | 'export'>('export');
  const [reference, setReference] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCreateCase({
      case_type: caseType,
      direction,
      reference: reference || undefined,
    });
    onClose();
    // Reset form
    setCaseType('booking');
    setDirection('export');
    setReference('');
  };

  if (!isOpen) return null;

  const getCaseNumberPreview = () => {
    const year = new Date().getFullYear().toString().slice(-2);
    const month = (new Date().getMonth() + 1).toString().padStart(2, '0');
    
    let prefix = 'H';
    if (caseType === 'booking') {
      prefix += direction === 'export' ? 'BE' : 'BI';
    } else {
      prefix += direction === 'export' ? 'QE' : 'QI';
    }
    
    return `${prefix} ${year} ${month} ####`;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-96 max-w-full mx-4">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Create New Case</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Case Type Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Case Type
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setCaseType('booking')}
                className={`flex items-center justify-center px-4 py-3 border-2 rounded-lg transition-colors ${
                  caseType === 'booking'
                    ? 'border-blue-500 bg-blue-50 text-blue-700'
                    : 'border-gray-200 hover:border-gray-300 text-gray-700'
                }`}
              >
                <Ship className="w-5 h-5 mr-2" />
                Booking
              </button>
              <button
                type="button"
                onClick={() => setCaseType('quotation')}
                className={`flex items-center justify-center px-4 py-3 border-2 rounded-lg transition-colors ${
                  caseType === 'quotation'
                    ? 'border-purple-500 bg-purple-50 text-purple-700'
                    : 'border-gray-200 hover:border-gray-300 text-gray-700'
                }`}
              >
                <FileText className="w-5 h-5 mr-2" />
                Quotation
              </button>
            </div>
          </div>

          {/* Direction Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Direction
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setDirection('export')}
                className={`px-4 py-2 border-2 rounded-lg transition-colors ${
                  direction === 'export'
                    ? 'border-green-500 bg-green-50 text-green-700'
                    : 'border-gray-200 hover:border-gray-300 text-gray-700'
                }`}
              >
                Export
              </button>
              <button
                type="button"
                onClick={() => setDirection('import')}
                className={`px-4 py-2 border-2 rounded-lg transition-colors ${
                  direction === 'import'
                    ? 'border-orange-500 bg-orange-50 text-orange-700'
                    : 'border-gray-200 hover:border-gray-300 text-gray-700'
                }`}
              >
                Import
              </button>
            </div>
          </div>

          {/* Case Number Preview */}
          <div className="bg-gray-50 p-3 rounded-lg">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Case Number (Auto-generated)
            </label>
            <div className="text-lg font-mono text-gray-900">
              {getCaseNumberPreview()}
            </div>
            <div className="text-xs text-gray-500 mt-1">
              Sequential number will be assigned automatically
            </div>
          </div>

          {/* Reference */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Reference (Optional)
            </label>
            <input
              type="text"
              value={reference}
              onChange={(e) => setReference(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Customer reference or internal note"
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Create Case
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewCaseModal;