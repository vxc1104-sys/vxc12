import React from 'react';
import { FileText, Package, Route, DollarSign, Files, History, Settings } from 'lucide-react';

export type NavigationSection = 
  | 'overview' 
  | 'goods' 
  | 'route' 
  | 'finance' 
  | 'documents' 
  | 'history' 
  | 'settings';

interface NavigationMenuProps {
  activeSection: NavigationSection;
  onSectionChange: (section: NavigationSection) => void;
}

const NavigationMenu: React.FC<NavigationMenuProps> = ({ activeSection, onSectionChange }) => {
  const menuItems = [
    { id: 'overview' as NavigationSection, label: 'Export Übersicht', icon: FileText, color: 'orange' },
    { id: 'goods' as NavigationSection, label: 'Ware', icon: Package, color: 'blue' },
    { id: 'route' as NavigationSection, label: 'Route', icon: Route, color: 'green' },
    { id: 'finance' as NavigationSection, label: 'Finanzen', icon: DollarSign, color: 'purple' },
    { id: 'documents' as NavigationSection, label: 'Dokumente', icon: Files, color: 'indigo' },
    { id: 'history' as NavigationSection, label: 'Änderungsverlauf', icon: History, color: 'gray' },
    { id: 'settings' as NavigationSection, label: 'Einstellungen', icon: Settings, color: 'teal' },
  ];

  return (
    <div className="w-48 bg-white border-r border-gray-200">
      {menuItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeSection === item.id;
        
        return (
          <div
            key={item.id}
            className={`flex items-center px-3 py-2 cursor-pointer transition-colors ${
              isActive 
                ? `bg-${item.color}-50 border-r-2 border-${item.color}-500 text-${item.color}-700` 
                : 'hover:bg-gray-50 text-gray-700'
            }`}
            onClick={() => onSectionChange(item.id)}
          >
            <Icon className={`w-4 h-4 mr-3 ${
              isActive ? `text-${item.color}-600` : 'text-gray-400'
            }`} />
            <span className="text-sm font-medium">{item.label}</span>
          </div>
        );
      })}
    </div>
  );
};

export default NavigationMenu;