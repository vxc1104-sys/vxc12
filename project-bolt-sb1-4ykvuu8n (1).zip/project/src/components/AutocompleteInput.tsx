import React, { useState, useEffect, useRef } from 'react';
import { Search, Plus } from 'lucide-react';

interface AutocompleteOption {
  id: string;
  label: string;
  value: string;
  subtitle?: string;
}

interface AutocompleteInputProps {
  value: string;
  onChange: (value: string, option?: AutocompleteOption) => void;
  onCreateNew?: (searchTerm: string) => void;
  options: AutocompleteOption[];
  placeholder?: string;
  className?: string;
  disabled?: boolean;
  allowCreate?: boolean;
  createLabel?: string;
}

const AutocompleteInput: React.FC<AutocompleteInputProps> = ({
  value,
  onChange,
  onCreateNew,
  options,
  placeholder = "Type to search...",
  className = "",
  disabled = false,
  allowCreate = false,
  createLabel = "Create new"
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState(value);
  const [filteredOptions, setFilteredOptions] = useState<AutocompleteOption[]>([]);
  const [highlightedIndex, setHighlightedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setSearchTerm(value);
  }, [value]);

  useEffect(() => {
    if (searchTerm.trim()) {
      const filtered = options.filter(option =>
        option.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
        option.value.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (option.subtitle && option.subtitle.toLowerCase().includes(searchTerm.toLowerCase()))
      );
      setFilteredOptions(filtered);
    } else {
      setFilteredOptions(options);
    }
    setHighlightedIndex(-1);
  }, [searchTerm, options]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setSearchTerm(newValue);
    onChange(newValue);
    setIsOpen(true);
  };

  const handleOptionSelect = (option: AutocompleteOption) => {
    setSearchTerm(option.label);
    onChange(option.value, option);
    setIsOpen(false);
    inputRef.current?.blur();
  };

  const handleCreateNew = () => {
    if (onCreateNew && searchTerm.trim()) {
      onCreateNew(searchTerm.trim());
      setIsOpen(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen) {
      if (e.key === 'ArrowDown' || e.key === 'Enter') {
        setIsOpen(true);
        return;
      }
    }

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        const maxIndex = allowCreate && searchTerm.trim() && filteredOptions.length === 0 ? 0 : filteredOptions.length - 1;
        setHighlightedIndex(prev => Math.min(prev + 1, maxIndex));
        break;
      
      case 'ArrowUp':
        e.preventDefault();
        setHighlightedIndex(prev => Math.max(prev - 1, -1));
        break;
      
      case 'Enter':
        e.preventDefault();
        if (highlightedIndex >= 0 && highlightedIndex < filteredOptions.length) {
          handleOptionSelect(filteredOptions[highlightedIndex]);
        } else if (allowCreate && searchTerm.trim() && filteredOptions.length === 0 && highlightedIndex === 0) {
          handleCreateNew();
        } else if (allowCreate && searchTerm.trim() && filteredOptions.length === 0) {
          handleCreateNew();
        }
        break;
      
      case 'Escape':
        setIsOpen(false);
        setHighlightedIndex(-1);
        inputRef.current?.blur();
        break;
    }
  };

  const handleFocus = () => {
    setIsOpen(true);
  };

  const handleBlur = (e: React.FocusEvent) => {
    // Delay closing to allow for option selection
    setTimeout(() => {
      if (!listRef.current?.contains(document.activeElement)) {
        setIsOpen(false);
        setHighlightedIndex(-1);
      }
    }, 150);
  };

  return (
    <div className="relative">
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={searchTerm}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onFocus={handleFocus}
          onBlur={handleBlur}
          disabled={disabled}
          placeholder={placeholder}
          className={`w-full pl-10 pr-4 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${className}`}
        />
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
      </div>

      {isOpen && (
        <div
          ref={listRef}
          className="absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto"
        >
          {filteredOptions.length > 0 ? (
            filteredOptions.map((option, index) => (
              <button
                key={option.id}
                type="button"
                onClick={() => handleOptionSelect(option)}
                className={`w-full text-left px-4 py-3 hover:bg-blue-50 focus:bg-blue-50 focus:outline-none ${
                  index === highlightedIndex ? 'bg-blue-50' : ''
                }`}
              >
                <div className="font-medium text-gray-900">{option.label}</div>
                {option.subtitle && (
                  <div className="text-sm text-gray-500">{option.subtitle}</div>
                )}
              </button>
            ))
          ) : searchTerm.trim() ? (
            allowCreate && onCreateNew ? (
              <button
                type="button"
                onClick={handleCreateNew}
                className={`w-full text-left px-4 py-3 hover:bg-green-50 focus:bg-green-50 focus:outline-none flex items-center ${
                  highlightedIndex === 0 ? 'bg-green-50' : ''
                }`}
              >
                <Plus className="w-4 h-4 mr-2 text-green-600" />
                <div>
                  <div className="font-medium text-green-700">
                    {createLabel}: "{searchTerm}"
                  </div>
                  <div className="text-sm text-green-600">Press Enter to create</div>
                </div>
              </button>
            ) : (
              <div className="px-4 py-3 text-gray-500 text-center">
                No results found
              </div>
            )
          ) : (
            <div className="px-4 py-3 text-gray-500 text-center">
              Start typing to search...
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AutocompleteInput;