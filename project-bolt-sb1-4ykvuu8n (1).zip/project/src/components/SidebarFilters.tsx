import React from 'react';
import { Filter, ChevronDown, ChevronRight } from 'lucide-react';

export interface FilterState {
  direction: 'all' | 'import' | 'export';
  type: 'all' | 'booking' | 'quotation';
  status: 'all' | 'draft' | 'active' | 'completed' | 'cancelled';
  dateRange: 'all' | 'today' | 'week' | 'month' | 'year';
}

interface SidebarFiltersProps {
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
  caseCount: number;
}

const SidebarFilters: React.FC<SidebarFiltersProps> = ({
  filters,
  onFiltersChange,
  caseCount
}) => {
  const [expandedSections, setExpandedSections] = React.useState<Set<string>>(
    new Set(['direction', 'type', 'status'])
  );

  const toggleSection = (section: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(section)) {
      newExpanded.delete(section);
    } else {
      newExpanded.add(section);
    }
    setExpandedSections(newExpanded);
  };

  const updateFilter = (key: keyof FilterState, value: any) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  const FilterSection: React.FC<{
    title: string;
    section: string;
    children: React.ReactNode;
  }> = ({ title, section, children }) => {
    const isExpanded = expandedSections.has(section);
    
    return (
      <div className="mb-4">
        <button
          onClick={() => toggleSection(section)}
          className="flex items-center w-full px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 rounded"
        >
          {isExpanded ? (
            <ChevronDown className="w-4 h-4 mr-2" />
          ) : (
            <ChevronRight className="w-4 h-4 mr-2" />
          )}
          {title}
        </button>
        {isExpanded && (
          <div className="ml-6 mt-2 space-y-1">
            {children}
          </div>
        )}
      </div>
    );
  };

  const FilterOption: React.FC<{
    label: string;
    value: string;
    currentValue: string;
    onChange: (value: string) => void;
    count?: number;
  }> = ({ label, value, currentValue, onChange, count }) => (
    <label className="flex items-center justify-between px-2 py-1 text-sm text-gray-600 hover:bg-gray-50 rounded cursor-pointer">
      <div className="flex items-center">
        <input
          type="radio"
          checked={currentValue === value}
          onChange={() => onChange(value)}
          className="mr-2 text-blue-600 focus:ring-blue-500"
        />
        {label}
      </div>
      {count !== undefined && (
        <span className="text-xs text-gray-400">({count})</span>
      )}
    </label>
  );

  return (
    <div className="w-64 bg-gray-50 border-r border-gray-300 flex flex-col h-full">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center">
          <Filter className="w-4 h-4 mr-2 text-gray-600" />
          <span className="text-sm font-medium text-gray-700">Filters</span>
        </div>
        <div className="text-xs text-gray-500 mt-1">
          {caseCount} cases found
        </div>
      </div>

      {/* Filter Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {/* Direction Filter */}
        <FilterSection title="Direction" section="direction">
          <FilterOption
            label="All Directions"
            value="all"
            currentValue={filters.direction}
            onChange={(value) => updateFilter('direction', value)}
          />
          <FilterOption
            label="Import"
            value="import"
            currentValue={filters.direction}
            onChange={(value) => updateFilter('direction', value)}
          />
          <FilterOption
            label="Export"
            value="export"
            currentValue={filters.direction}
            onChange={(value) => updateFilter('direction', value)}
          />
        </FilterSection>

        {/* Type Filter */}
        <FilterSection title="Case Type" section="type">
          <FilterOption
            label="All Types"
            value="all"
            currentValue={filters.type}
            onChange={(value) => updateFilter('type', value)}
          />
          <FilterOption
            label="Booking"
            value="booking"
            currentValue={filters.type}
            onChange={(value) => updateFilter('type', value)}
          />
          <FilterOption
            label="Quotation"
            value="quotation"
            currentValue={filters.type}
            onChange={(value) => updateFilter('type', value)}
          />
        </FilterSection>

        {/* Status Filter */}
        <FilterSection title="Status" section="status">
          <FilterOption
            label="All Status"
            value="all"
            currentValue={filters.status}
            onChange={(value) => updateFilter('status', value)}
          />
          <FilterOption
            label="Draft"
            value="draft"
            currentValue={filters.status}
            onChange={(value) => updateFilter('status', value)}
          />
          <FilterOption
            label="Active"
            value="active"
            currentValue={filters.status}
            onChange={(value) => updateFilter('status', value)}
          />
          <FilterOption
            label="Completed"
            value="completed"
            currentValue={filters.status}
            onChange={(value) => updateFilter('status', value)}
          />
          <FilterOption
            label="Cancelled"
            value="cancelled"
            currentValue={filters.status}
            onChange={(value) => updateFilter('status', value)}
          />
        </FilterSection>

        {/* Date Range Filter */}
        <FilterSection title="Date Range" section="dateRange">
          <FilterOption
            label="All Time"
            value="all"
            currentValue={filters.dateRange}
            onChange={(value) => updateFilter('dateRange', value)}
          />
          <FilterOption
            label="Today"
            value="today"
            currentValue={filters.dateRange}
            onChange={(value) => updateFilter('dateRange', value)}
          />
          <FilterOption
            label="This Week"
            value="week"
            currentValue={filters.dateRange}
            onChange={(value) => updateFilter('dateRange', value)}
          />
          <FilterOption
            label="This Month"
            value="month"
            currentValue={filters.dateRange}
            onChange={(value) => updateFilter('dateRange', value)}
          />
          <FilterOption
            label="This Year"
            value="year"
            currentValue={filters.dateRange}
            onChange={(value) => updateFilter('dateRange', value)}
          />
        </FilterSection>
      </div>

      {/* Clear Filters */}
      <div className="border-t border-gray-200 p-4">
        <button
          onClick={() => onFiltersChange({
            direction: 'all',
            type: 'all',
            status: 'all',
            dateRange: 'all'
          })}
          className="w-full px-3 py-2 text-sm text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded transition-colors"
        >
          Clear All Filters
        </button>
      </div>
    </div>
  );
};

export default SidebarFilters;