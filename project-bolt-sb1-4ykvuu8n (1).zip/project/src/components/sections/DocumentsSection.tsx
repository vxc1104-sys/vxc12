import React, { useState, useEffect } from 'react';
import { Files, Upload, Download, Eye, Trash2, Plus } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import DocumentCreationWindow from '../DocumentCreationWindow';

interface Document {
  id: string;
  file_name: string;
  file_url: string;
  file_type: string | null;
  document_category: string | null;
  uploaded_at: string;
}

interface DocumentsSectionProps {
  caseId: string;
}

const DocumentsSection: React.FC<DocumentsSectionProps> = ({ caseId }) => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploadingFiles, setUploadingFiles] = useState<string[]>([]);
  const [showDocumentCreation, setShowDocumentCreation] = useState(false);
  const [caseData, setCaseData] = useState<any>(null);

  useEffect(() => {
    fetchDocuments();
    fetchCaseData();
  }, [caseId]);

  const fetchDocuments = async () => {
    try {
      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .eq('case_id', caseId)
        .order('uploaded_at', { ascending: false });

      if (error) throw error;
      setDocuments(data || []);
    } catch (error) {
      console.error('Error fetching documents:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCaseData = async () => {
    try {
      const { data, error } = await supabase
        .from('cases')
        .select(`
          *,
          customers (
            company_name
          )
        `)
        .eq('id', caseId)
        .single();

      if (error) throw error;
      setCaseData(data);
    } catch (error) {
      console.error('Error fetching case data:', error);
    }
  };

  const handleFileUpload = async (files: FileList) => {
    for (const file of Array.from(files)) {
      const fileName = file.name;
      setUploadingFiles(prev => [...prev, fileName]);

      try {
        // In a real implementation, you would upload to Supabase Storage
        // For now, we'll create a mock document entry
        const mockDocument = {
          case_id: caseId,
          file_name: fileName,
          file_url: `mock://uploads/${fileName}`,
          file_type: file.type || null,
          document_category: getDocumentCategory(fileName),
        };

        const { data, error } = await supabase
          .from('documents')
          .insert([mockDocument])
          .select()
          .single();

        if (error) throw error;
        setDocuments(prev => [data, ...prev]);
      } catch (error) {
        console.error('Error uploading document:', error);
      } finally {
        setUploadingFiles(prev => prev.filter(name => name !== fileName));
      }
    }
  };

  const getDocumentCategory = (fileName: string): string => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'pdf':
        return 'contract';
      case 'xlsx':
      case 'xls':
        return 'invoice';
      case 'jpg':
      case 'jpeg':
      case 'png':
        return 'photo';
      default:
        return 'other';
    }
  };

  const deleteDocument = async (documentId: string) => {
    try {
      const { error } = await supabase
        .from('documents')
        .delete()
        .eq('id', documentId);

      if (error) throw error;
      setDocuments(prev => prev.filter(doc => doc.id !== documentId));
    } catch (error) {
      console.error('Error deleting document:', error);
    }
  };

  const getCategoryColor = (category: string | null) => {
    switch (category) {
      case 'contract':
        return 'bg-blue-100 text-blue-800';
      case 'invoice':
        return 'bg-green-100 text-green-800';
      case 'photo':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return <div className="p-6">Loading documents...</div>;
  }

  return (
    <div className="flex-1 bg-white overflow-y-auto">
      {/* Header */}
      <div className="bg-indigo-50 border-b border-indigo-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-indigo-800 flex items-center">
            <Files className="w-5 h-5 mr-2" />
            Dokumente
          </h2>
          
          <div className="flex space-x-2">
            <button
              onClick={() => setShowDocumentCreation(true)}
              className="flex items-center px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Document
            </button>
            
            <label className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 cursor-pointer">
              <Upload className="w-4 h-4 mr-2" />
              Upload Files
              <input
                type="file"
                multiple
                className="hidden"
                onChange={(e) => e.target.files && handleFileUpload(e.target.files)}
              />
            </label>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* Upload Area */}
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center mb-6 hover:border-indigo-400 transition-colors">
          <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600 mb-2">Drag and drop files here, or click to select</p>
          <p className="text-sm text-gray-500">Supports PDF, Excel, Images, and other document types</p>
          
          <label className="inline-block mt-4 px-4 py-2 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 cursor-pointer">
            Select Files
            <input
              type="file"
              multiple
              className="hidden"
              onChange={(e) => e.target.files && handleFileUpload(e.target.files)}
            />
          </label>
        </div>

        {/* Uploading Files */}
        {uploadingFiles.length > 0 && (
          <div className="mb-6">
            <h3 className="text-sm font-medium text-gray-700 mb-2">Uploading...</h3>
            {uploadingFiles.map(fileName => (
              <div key={fileName} className="flex items-center space-x-2 mb-2">
                <div className="animate-spin w-4 h-4 border-2 border-indigo-600 border-t-transparent rounded-full"></div>
                <span className="text-sm text-gray-600">{fileName}</span>
              </div>
            ))}
          </div>
        )}

        {/* Documents List */}
        <div className="space-y-3">
          <h3 className="text-sm font-medium text-gray-700">
            Documents ({documents.length})
          </h3>
          
          {documents.length === 0 ? (
            <div className="text-center py-8">
              <Files className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No documents uploaded yet</p>
            </div>
          ) : (
            <div className="grid gap-3">
              {documents.map(document => (
                <div
                  key={document.id}
                  className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50"
                >
                  <div className="flex items-center space-x-3">
                    <Files className="w-8 h-8 text-gray-400" />
                    <div>
                      <div className="font-medium text-gray-900">{document.file_name}</div>
                      <div className="flex items-center space-x-2 text-sm text-gray-500">
                        <span>{new Date(document.uploaded_at).toLocaleDateString()}</span>
                        {document.document_category && (
                          <span className={`px-2 py-1 rounded-full text-xs ${getCategoryColor(document.document_category)}`}>
                            {document.document_category}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button className="p-2 text-gray-400 hover:text-blue-600 rounded">
                      <Eye className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-gray-400 hover:text-green-600 rounded">
                      <Download className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => deleteDocument(document.id)}
                      className="p-2 text-gray-400 hover:text-red-600 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Document Creation Window */}
      <DocumentCreationWindow
        isOpen={showDocumentCreation}
        onClose={() => setShowDocumentCreation(false)}
        caseId={caseId}
        caseData={{
          case_number: caseData?.case_number || '',
          customer_name: caseData?.customers?.company_name || '',
          customer_reference: caseData?.customer_reference || '',
          service_type: caseData?.service_type || '',
          vessel_name: caseData?.vessel_name || '',
          carrier: caseData?.carrier || '',
          pickup_date: caseData?.pickup_date || '',
          delivery_date: caseData?.delivery_date || '',
          standard_closing: caseData?.standard_closing || '',
          vwm_closing: caseData?.vwm_closing || '',
          cy_closing: caseData?.cy_closing || '',
        }}
      />
    </div>
  );
};

export default DocumentsSection;