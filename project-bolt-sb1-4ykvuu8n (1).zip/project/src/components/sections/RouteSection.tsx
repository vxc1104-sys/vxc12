import React, { useState, useEffect } from 'react';
import { Route as RouteIcon, MapPin, Ship, Calendar } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface Port {
  id: string;
  code: string;
  name: string;
  country: string;
}

interface RouteData {
  id: string;
  origin_port_id: string | null;
  destination_port_id: string | null;
  loading_port_id: string | null;
  discharge_port_id: string | null;
  carrier: string | null;
  shipping_line: string | null;
  vessel: string | null;
  voyage: string | null;
}

interface RouteSectionProps {
  caseId: string;
}

const RouteSection: React.FC<RouteSectionProps> = ({ caseId }) => {
  const [route, setRoute] = useState<RouteData | null>(null);
  const [ports, setPorts] = useState<Port[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, [caseId]);

  const fetchData = async () => {
    try {
      // Fetch ports
      const { data: portsData, error: portsError } = await supabase
        .from('ports')
        .select('*')
        .order('name');

      if (portsError) throw portsError;
      setPorts(portsData || []);

      // Fetch route
      const { data: routeData, error: routeError } = await supabase
        .from('routes')
        .select('*')
        .eq('case_id', caseId)
        .single();

      if (routeError && routeError.code !== 'PGRST116') throw routeError;
      setRoute(routeData || createEmptyRoute());
    } catch (error) {
      console.error('Error fetching route data:', error);
      setRoute(createEmptyRoute());
    } finally {
      setLoading(false);
    }
  };

  const createEmptyRoute = (): RouteData => ({
    id: '',
    origin_port_id: null,
    destination_port_id: null,
    loading_port_id: null,
    discharge_port_id: null,
    carrier: null,
    shipping_line: null,
    vessel: null,
    voyage: null,
  });

  const handleFieldUpdate = async (field: string, value: any) => {
    if (!route) return;

    try {
      if (route.id) {
        // Update existing
        const { error } = await supabase
          .from('routes')
          .update({ [field]: value })
          .eq('id', route.id);

        if (error) throw error;
      } else {
        // Create new
        const newRoute = { case_id: caseId, [field]: value };
        const { data, error } = await supabase
          .from('routes')
          .insert([newRoute])
          .select()
          .single();

        if (error) throw error;
        setRoute({ ...route, ...data });
        return;
      }

      setRoute(prev => prev ? { ...prev, [field]: value } : null);
    } catch (error) {
      console.error('Error updating route:', error);
    }
  };

  const getPortDisplay = (portId: string | null) => {
    if (!portId) return '';
    const port = ports.find(p => p.id === portId);
    return port ? `${port.name} (${port.code})` : '';
  };

  if (loading) {
    return <div className="p-6">Loading...</div>;
  }

  return (
    <div className="flex-1 bg-white overflow-y-auto">
      {/* Header */}
      <div className="bg-green-50 border-b border-green-200 px-6 py-4">
        <h2 className="text-lg font-semibold text-green-800 flex items-center">
          <RouteIcon className="w-5 h-5 mr-2" />
          Route - Orte und Route
        </h2>
      </div>

      <div className="p-6">
        <div className="max-w-5xl grid grid-cols-2 gap-8">
          {/* Left Column - Ports */}
          <div className="space-y-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-blue-800 mb-4 flex items-center">
                <MapPin className="w-4 h-4 mr-2" />
                Port Information
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Origin Port</label>
                  <select
                    value={route?.origin_port_id || ''}
                    onChange={(e) => handleFieldUpdate('origin_port_id', e.target.value || null)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Select origin port</option>
                    {ports.map(port => (
                      <option key={port.id} value={port.id}>
                        {port.name} ({port.code}) - {port.country}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Loading Port</label>
                  <select
                    value={route?.loading_port_id || ''}
                    onChange={(e) => handleFieldUpdate('loading_port_id', e.target.value || null)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Select loading port</option>
                    {ports.map(port => (
                      <option key={port.id} value={port.id}>
                        {port.name} ({port.code}) - {port.country}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Discharge Port</label>
                  <select
                    value={route?.discharge_port_id || ''}
                    onChange={(e) => handleFieldUpdate('discharge_port_id', e.target.value || null)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Select discharge port</option>
                    {ports.map(port => (
                      <option key={port.id} value={port.id}>
                        {port.name} ({port.code}) - {port.country}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Destination Port</label>
                  <select
                    value={route?.destination_port_id || ''}
                    onChange={(e) => handleFieldUpdate('destination_port_id', e.target.value || null)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Select destination port</option>
                    {ports.map(port => (
                      <option key={port.id} value={port.id}>
                        {port.name} ({port.code}) - {port.country}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Route Summary */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-gray-800 mb-4">Route Summary</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center">
                  <span className="w-16 text-gray-600">Origin:</span>
                  <span className="text-gray-800">{getPortDisplay(route?.origin_port_id)}</span>
                </div>
                <div className="flex items-center">
                  <span className="w-16 text-gray-600">Loading:</span>
                  <span className="text-gray-800">{getPortDisplay(route?.loading_port_id)}</span>
                </div>
                <div className="flex items-center text-green-600">
                  <RouteIcon className="w-4 h-4 mr-2" />
                  <span>Ocean Transit</span>
                </div>
                <div className="flex items-center">
                  <span className="w-16 text-gray-600">Discharge:</span>
                  <span className="text-gray-800">{getPortDisplay(route?.discharge_port_id)}</span>
                </div>
                <div className="flex items-center">
                  <span className="w-16 text-gray-600">Destination:</span>
                  <span className="text-gray-800">{getPortDisplay(route?.destination_port_id)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Carrier Information */}
          <div className="space-y-6">
            <div className="bg-purple-50 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-purple-800 mb-4 flex items-center">
                <Ship className="w-4 h-4 mr-2" />
                Carrier & Vessel Information
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Carrier</label>
                  <input
                    type="text"
                    value={route?.carrier || ''}
                    onChange={(e) => handleFieldUpdate('carrier', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g., MSC, Maersk, COSCO"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Shipping Line</label>
                  <input
                    type="text"
                    value={route?.shipping_line || ''}
                    onChange={(e) => handleFieldUpdate('shipping_line', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Shipping line name"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Vessel Name</label>
                  <input
                    type="text"
                    value={route?.vessel || ''}
                    onChange={(e) => handleFieldUpdate('vessel', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Vessel name"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Voyage Number</label>
                  <input
                    type="text"
                    value={route?.voyage || ''}
                    onChange={(e) => handleFieldUpdate('voyage', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Voyage/rotation number"
                  />
                </div>
              </div>
            </div>

            {/* Transit Information */}
            <div className="bg-yellow-50 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-yellow-800 mb-4 flex items-center">
                <Calendar className="w-4 h-4 mr-2" />
                Transit Information
              </h3>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">ETD (Loading Port)</label>
                    <input
                      type="date"
                      className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">ETA (Discharge Port)</label>
                    <input
                      type="date"
                      className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Transit Time</label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm bg-gray-50"
                    placeholder="Calculated automatically"
                    disabled
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Service Type</label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500">
                    <option>Direct Service</option>
                    <option>Transshipment Service</option>
                    <option>Feeder Service</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Additional Notes */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-gray-800 mb-4">Route Notes</h3>
              <textarea
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500 resize-none"
                placeholder="Special routing instructions, transshipment details, restrictions, etc."
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RouteSection;