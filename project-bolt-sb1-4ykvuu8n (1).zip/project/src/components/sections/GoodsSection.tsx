import React, { useState, useEffect } from 'react';
import { Package, Weight, Ruler, Hash } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface Goods {
  id: string;
  description: string | null;
  hs_code: string | null;
  weight_kg: number | null;
  volume_cbm: number | null;
  packages: number | null;
  packaging_type: string | null;
  container_type: string | null;
  container_count: number;
}

interface GoodsSectionProps {
  caseId: string;
}

const GoodsSection: React.FC<GoodsSectionProps> = ({ caseId }) => {
  const [goods, setGoods] = useState<Goods | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchGoods();
  }, [caseId]);

  const fetchGoods = async () => {
    try {
      const { data, error } = await supabase
        .from('goods')
        .select('*')
        .eq('case_id', caseId)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      setGoods(data || createEmptyGoods());
    } catch (error) {
      console.error('Error fetching goods:', error);
      setGoods(createEmptyGoods());
    } finally {
      setLoading(false);
    }
  };

  const createEmptyGoods = (): Goods => ({
    id: '',
    description: null,
    hs_code: null,
    weight_kg: null,
    volume_cbm: null,
    packages: null,
    packaging_type: null,
    container_type: null,
    container_count: 1,
  });

  const handleFieldUpdate = async (field: string, value: any) => {
    if (!goods) return;

    try {
      if (goods.id) {
        // Update existing
        const { error } = await supabase
          .from('goods')
          .update({ [field]: value })
          .eq('id', goods.id);

        if (error) throw error;
      } else {
        // Create new
        const newGoods = { case_id: caseId, [field]: value };
        const { data, error } = await supabase
          .from('goods')
          .insert([newGoods])
          .select()
          .single();

        if (error) throw error;
        setGoods({ ...goods, ...data });
        return;
      }

      setGoods(prev => prev ? { ...prev, [field]: value } : null);
    } catch (error) {
      console.error('Error updating goods:', error);
    }
  };

  if (loading) {
    return <div className="p-6">Loading...</div>;
  }

  return (
    <div className="flex-1 bg-white overflow-y-auto">
      {/* Header */}
      <div className="bg-blue-50 border-b border-blue-200 px-6 py-4">
        <h2 className="text-lg font-semibold text-blue-800 flex items-center">
          <Package className="w-5 h-5 mr-2" />
          Ware - Cargo Details
        </h2>
      </div>

      <div className="p-6">
        <div className="max-w-4xl grid grid-cols-2 gap-8">
          {/* Left Column - Cargo Description */}
          <div className="space-y-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-blue-800 mb-4">Cargo Description</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Description</label>
                  <textarea
                    value={goods?.description || ''}
                    onChange={(e) => handleFieldUpdate('description', e.target.value)}
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500 resize-none"
                    placeholder="Detailed cargo description..."
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1 flex items-center">
                    <Hash className="w-3 h-3 mr-1" />
                    HS Code
                  </label>
                  <input
                    type="text"
                    value={goods?.hs_code || ''}
                    onChange={(e) => handleFieldUpdate('hs_code', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g., 8901.20.10"
                  />
                </div>
              </div>
            </div>

            {/* Packaging Information */}
            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-green-800 mb-4">Packaging</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Packages</label>
                  <input
                    type="number"
                    value={goods?.packages || ''}
                    onChange={(e) => handleFieldUpdate('packages', e.target.value ? parseInt(e.target.value) : null)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    min="0"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Packaging Type</label>
                  <select
                    value={goods?.packaging_type || ''}
                    onChange={(e) => handleFieldUpdate('packaging_type', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Select type</option>
                    <option value="cartons">Cartons</option>
                    <option value="pallets">Pallets</option>
                    <option value="cases">Cases</option>
                    <option value="drums">Drums</option>
                    <option value="bales">Bales</option>
                    <option value="rolls">Rolls</option>
                    <option value="bundles">Bundles</option>
                    <option value="bags">Bags</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Measurements & Container */}
          <div className="space-y-6">
            <div className="bg-yellow-50 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-yellow-800 mb-4 flex items-center">
                <Weight className="w-4 h-4 mr-2" />
                Measurements
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Weight (kg)</label>
                  <input
                    type="number"
                    value={goods?.weight_kg || ''}
                    onChange={(e) => handleFieldUpdate('weight_kg', e.target.value ? parseFloat(e.target.value) : null)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    step="0.01"
                    min="0"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1 flex items-center">
                    <Ruler className="w-3 h-3 mr-1" />
                    Volume (CBM)
                  </label>
                  <input
                    type="number"
                    value={goods?.volume_cbm || ''}
                    onChange={(e) => handleFieldUpdate('volume_cbm', e.target.value ? parseFloat(e.target.value) : null)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    step="0.01"
                    min="0"
                  />
                </div>
              </div>
            </div>

            {/* Container Information */}
            <div className="bg-purple-50 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-purple-800 mb-4">Container Information</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Container Type</label>
                  <select
                    value={goods?.container_type || ''}
                    onChange={(e) => handleFieldUpdate('container_type', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Select container type</option>
                    <option value="20DC">20' Dry Container</option>
                    <option value="40DC">40' Dry Container</option>
                    <option value="40HC">40' High Cube</option>
                    <option value="20RF">20' Reefer</option>
                    <option value="40RF">40' Reefer</option>
                    <option value="20OT">20' Open Top</option>
                    <option value="40OT">40' Open Top</option>
                    <option value="20FR">20' Flat Rack</option>
                    <option value="40FR">40' Flat Rack</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Container Count</label>
                  <input
                    type="number"
                    value={goods?.container_count || 1}
                    onChange={(e) => handleFieldUpdate('container_count', parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    min="1"
                  />
                </div>
              </div>
            </div>

            {/* Additional Information */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-gray-800 mb-4">Additional Notes</h3>
              <textarea
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500 resize-none"
                placeholder="Special handling instructions, dangerous goods information, etc."
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GoodsSection;