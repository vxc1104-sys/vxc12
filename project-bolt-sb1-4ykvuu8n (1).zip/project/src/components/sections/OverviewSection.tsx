import React, { useState, useEffect } from 'react';
import { Calendar, User, MapPin, Clock } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import AutocompleteInput from '../AutocompleteInput';
import CustomerFormWindow from '../CustomerFormWindow';

interface Customer {
  id: string;
  company_name: string;
  contact_person_primary: string | null;
}

interface CaseOverview {
  id: string;
  case_number: string;
  customer_id: string | null;
  reference: string | null;
  booking_code: string | null;
  service_type: string;
  incoterms: string;
  validity_from: string | null;
  validity_to: string | null;
  departure_date: string | null;
  arrival_date: string | null;
  internal_comments: string | null;
  status: string;
  case_type: string;
  customer_reference: string | null;
  vessel_name: string | null;
  carrier: string | null;
  pickup_date: string | null;
  delivery_date: string | null;
  standard_closing: string | null;
  vwm_closing: string | null;
  cy_closing: string | null;
  dock_closing_carrier: string | null;
  dock_closing_customer: string | null;
}

interface OverviewSectionProps {
  caseId: string;
}

const OverviewSection: React.FC<OverviewSectionProps> = ({ caseId }) => {
  const [caseData, setCaseData] = useState<CaseOverview | null>(null);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [showCustomerForm, setShowCustomerForm] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, [caseId]);

  const fetchData = async () => {
    try {
      // Fetch case data
      const { data: caseResult, error: caseError } = await supabase
        .from('cases')
        .select('*')
        .eq('id', caseId)
        .single();

      if (caseError) throw caseError;
      setCaseData(caseResult);

      // Fetch customers for dropdown
      const { data: customersResult, error: customersError } = await supabase
        .from('customers')
        .select('id, company_name, contact_person_primary')
        .eq('is_active', true)
        .order('company_name');

      if (customersError) throw customersError;
      setCustomers(customersResult || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFieldUpdate = async (field: string, value: any) => {
    if (!caseData) return;

    try {
      const { error } = await supabase
        .from('cases')
        .update({ [field]: value, updated_at: new Date().toISOString() })
        .eq('id', caseId);

      if (error) throw error;

      setCaseData(prev => prev ? { ...prev, [field]: value } : null);
    } catch (error) {
      console.error('Error updating case:', error);
    }
  };

  const handleCustomerSelect = async (customerId: string) => {
    await handleFieldUpdate('customer_id', customerId);
  };

  const handleCreateCustomer = (searchTerm: string) => {
    setShowCustomerForm(true);
  };

  const handleCustomerSaved = (customer: Customer) => {
    setCustomers(prev => [...prev, customer]);
    handleFieldUpdate('customer_id', customer.id);
    setShowCustomerForm(false);
  };

  const getCustomerOptions = () => {
    return customers.map(customer => ({
      id: customer.id,
      label: customer.company_name,
      value: customer.id,
      subtitle: customer.contact_person_primary || undefined
    }));
  };

  const getSelectedCustomerName = () => {
    const customer = customers.find(c => c.id === caseData?.customer_id);
    return customer?.company_name || '';
  };

  if (loading || !caseData) {
    return <div className="p-6">Loading...</div>;
  }

  return (
    <div className="flex-1 bg-white overflow-y-auto">
      {/* Header */}
      <div className="bg-orange-50 border-b border-orange-200 px-6 py-4">
        <h2 className="text-lg font-semibold text-orange-800 flex items-center">
          <User className="w-5 h-5 mr-2" />
          {caseData.case_type === 'quotation' ? 'Quotation' : 'Export'} Übersicht - {caseData.case_number}
        </h2>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-2 gap-8">
          {/* Left Column - Customer Information */}
          <div className="space-y-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-blue-800 mb-4">Kunde</h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Kunde</label>
                  <AutocompleteInput
                    value={getSelectedCustomerName()}
                    onChange={(value, option) => {
                      if (option) {
                        handleCustomerSelect(option.value);
                      }
                    }}
                    onCreateNew={handleCreateCustomer}
                    options={getCustomerOptions()}
                    placeholder="Search customers..."
                    allowCreate={true}
                    createLabel="Create customer"
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Kontakt</label>
                  <input
                    type="text"
                    value={customers.find(c => c.id === caseData.customer_id)?.contact_person_primary || ''}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm bg-gray-50"
                    disabled
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Referenz</label>
                  <input
                    type="text"
                    value={caseData.reference || ''}
                    onChange={(e) => handleFieldUpdate('reference', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                {caseData.case_type === 'booking' && (
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Customer Reference</label>
                    <input
                      type="text"
                      value={caseData.customer_reference || ''}
                      onChange={(e) => handleFieldUpdate('customer_reference', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Booking Information */}
            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-green-800 mb-4">Buchungscode</h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Einkaufsratenkontrakt</label>
                  <input
                    type="text"
                    value={caseData.booking_code || ''}
                    onChange={(e) => handleFieldUpdate('booking_code', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Verkaufsratenkontrakt</label>
                  <input
                    type="text"
                    value={caseData.reference || ''}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm bg-gray-50"
                    disabled
                  />
                </div>
              </div>
            </div>

            {/* Service Settings */}
            <div className="bg-purple-50 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-purple-800 mb-4">Service</h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Servicetyp</label>
                  <select
                    value={caseData.service_type}
                    onChange={(e) => handleFieldUpdate('service_type', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="FCL">FCL</option>
                    <option value="LCL">LCL</option>
                    <option value="Air">Air Freight</option>
                    <option value="Road">Road Transport</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Incoterms</label>
                  <select
                    value={caseData.incoterms}
                    onChange={(e) => handleFieldUpdate('incoterms', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="FOB">FOB</option>
                    <option value="CIF">CIF</option>
                    <option value="EXW">EXW</option>
                    <option value="DDP">DDP</option>
                    <option value="FCA">FCA</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Booking-specific fields */}
            {caseData.case_type === 'booking' && (
              <div className="bg-indigo-50 p-4 rounded-lg">
                <h3 className="text-sm font-semibold text-indigo-800 mb-4">Vessel Information</h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Vessel Name</label>
                    <input
                      type="text"
                      value={caseData.vessel_name || ''}
                      onChange={(e) => handleFieldUpdate('vessel_name', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Carrier (Reeder)</label>
                    <input
                      type="text"
                      value={caseData.carrier || ''}
                      onChange={(e) => handleFieldUpdate('carrier', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Right Column - Additional Information */}
          <div className="space-y-6">
            {/* Dates */}
            {caseData.case_type === 'quotation' ? (
              <div className="bg-yellow-50 p-4 rounded-lg">
                <h3 className="text-sm font-semibold text-yellow-800 mb-4 flex items-center">
                  <Calendar className="w-4 h-4 mr-2" />
                  Gültigkeitsbereich
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Von</label>
                    <input
                      type="date"
                      value={caseData.validity_from || ''}
                      onChange={(e) => handleFieldUpdate('validity_from', e.target.value || null)}
                      className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Bis</label>
                    <input
                      type="date"
                      value={caseData.validity_to || ''}
                      onChange={(e) => handleFieldUpdate('validity_to', e.target.value || null)}
                      className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-yellow-50 p-4 rounded-lg">
                <h3 className="text-sm font-semibold text-yellow-800 mb-4 flex items-center">
                  <Calendar className="w-4 h-4 mr-2" />
                  Container Dates
                </h3>
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Pickup Date</label>
                      <input
                        type="datetime-local"
                        value={caseData.pickup_date ? new Date(caseData.pickup_date).toISOString().slice(0, 16) : ''}
                        onChange={(e) => handleFieldUpdate('pickup_date', e.target.value ? new Date(e.target.value).toISOString() : null)}
                        className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Delivery Date</label>
                      <input
                        type="datetime-local"
                        value={caseData.delivery_date ? new Date(caseData.delivery_date).toISOString().slice(0, 16) : ''}
                        onChange={(e) => handleFieldUpdate('delivery_date', e.target.value ? new Date(e.target.value).toISOString() : null)}
                        className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Booking-specific closing dates */}
            {caseData.case_type === 'booking' && (
              <div className="bg-teal-50 p-4 rounded-lg">
                <h3 className="text-sm font-semibold text-teal-800 mb-4 flex items-center">
                  <Clock className="w-4 h-4 mr-2" />
                  Closing Dates
                </h3>
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Standard Closing</label>
                      <input
                        type="datetime-local"
                        value={caseData.standard_closing ? new Date(caseData.standard_closing).toISOString().slice(0, 16) : ''}
                        onChange={(e) => handleFieldUpdate('standard_closing', e.target.value ? new Date(e.target.value).toISOString() : null)}
                        className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">VWM Closing</label>
                      <input
                        type="datetime-local"
                        value={caseData.vwm_closing ? new Date(caseData.vwm_closing).toISOString().slice(0, 16) : ''}
                        onChange={(e) => handleFieldUpdate('vwm_closing', e.target.value ? new Date(e.target.value).toISOString() : null)}
                        className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">CY Closing</label>
                      <input
                        type="datetime-local"
                        value={caseData.cy_closing ? new Date(caseData.cy_closing).toISOString().slice(0, 16) : ''}
                        onChange={(e) => handleFieldUpdate('cy_closing', e.target.value ? new Date(e.target.value).toISOString() : null)}
                        className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Dock Closing (Carrier)</label>
                      <input
                        type="datetime-local"
                        value={caseData.dock_closing_carrier ? new Date(caseData.dock_closing_carrier).toISOString().slice(0, 16) : ''}
                        onChange={(e) => handleFieldUpdate('dock_closing_carrier', e.target.value ? new Date(e.target.value).toISOString() : null)}
                        className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Dock Closing (Customer)</label>
                    <input
                      type="datetime-local"
                      value={caseData.dock_closing_customer ? new Date(caseData.dock_closing_customer).toISOString().slice(0, 16) : ''}
                      onChange={(e) => handleFieldUpdate('dock_closing_customer', e.target.value ? new Date(e.target.value).toISOString() : null)}
                      className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Internal Comments */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-gray-800 mb-4">Internal Comments</h3>
              <textarea
                value={caseData.internal_comments || ''}
                onChange={(e) => handleFieldUpdate('internal_comments', e.target.value)}
                rows={6}
                className="w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500 resize-none"
                placeholder="Internal comments, not printing"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Customer Form Window */}
      <CustomerFormWindow
        isOpen={showCustomerForm}
        onClose={() => setShowCustomerForm(false)}
        onSave={handleCustomerSaved}
      />
    </div>
  );
};

export default OverviewSection;