import React, { useState, useEffect } from 'react';
import { History, User, Clock, Edit3 } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface ChangeHistoryItem {
  id: string;
  table_name: string;
  field_name: string;
  old_value: string | null;
  new_value: string | null;
  changed_by: string;
  changed_at: string;
}

interface HistorySectionProps {
  caseId: string;
}

const HistorySection: React.FC<HistorySectionProps> = ({ caseId }) => {
  const [history, setHistory] = useState<ChangeHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'today' | 'week'>('all');

  useEffect(() => {
    fetchHistory();
  }, [caseId, filter]);

  const fetchHistory = async () => {
    try {
      let query = supabase
        .from('change_history')
        .select('*')
        .eq('case_id', caseId)
        .order('changed_at', { ascending: false });

      // Apply date filter
      if (filter === 'today') {
        const today = new Date().toISOString().split('T')[0];
        query = query.gte('changed_at', today);
      } else if (filter === 'week') {
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        query = query.gte('changed_at', weekAgo.toISOString());
      }

      const { data, error } = await query;

      if (error) throw error;
      setHistory(data || []);
    } catch (error) {
      console.error('Error fetching history:', error);
    } finally {
      setLoading(false);
    }
  };

  const getFieldDisplayName = (tableName: string, fieldName: string) => {
    const fieldMap: Record<string, Record<string, string>> = {
      cases: {
        reference: 'Reference',
        status: 'Status',
        departure_date: 'Departure Date',
        arrival_date: 'Arrival Date',
        customer_id: 'Customer',
        internal_comments: 'Internal Comments'
      },
      goods: {
        description: 'Cargo Description',
        weight_kg: 'Weight (kg)',
        volume_cbm: 'Volume (CBM)',
        container_type: 'Container Type'
      },
      finance_items: {
        description: 'Service Description',
        supplier_cost: 'Purchase Price',
        sales_price: 'Sales Price',
        supplier: 'Supplier'
      }
    };

    return fieldMap[tableName]?.[fieldName] || fieldName;
  };

  const getTableDisplayName = (tableName: string) => {
    const tableMap: Record<string, string> = {
      cases: 'Case Overview',
      goods: 'Goods',
      routes: 'Route',
      finance_items: 'Finance',
      documents: 'Documents'
    };

    return tableMap[tableName] || tableName;
  };

  const formatValue = (value: string | null) => {
    if (value === null || value === '') return '(empty)';
    if (value.length > 50) return value.substring(0, 50) + '...';
    return value;
  };

  const getChangeIcon = (tableName: string) => {
    switch (tableName) {
      case 'finance_items':
        return '💰';
      case 'goods':
        return '📦';
      case 'routes':
        return '🚢';
      case 'documents':
        return '📄';
      default:
        return '📝';
    }
  };

  if (loading) {
    return <div className="p-6">Loading change history...</div>;
  }

  return (
    <div className="flex-1 bg-white overflow-y-auto">
      {/* Header */}
      <div className="bg-gray-50 border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-800 flex items-center">
            <History className="w-5 h-5 mr-2" />
            Änderungsverlauf
          </h2>
          
          <div className="flex items-center space-x-2">
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value as 'all' | 'today' | 'week')}
              className="px-3 py-1 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="all">All Changes</option>
              <option value="today">Today</option>
              <option value="week">This Week</option>
            </select>
          </div>
        </div>
      </div>

      <div className="p-6">
        {history.length === 0 ? (
          <div className="text-center py-12">
            <History className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Changes Found</h3>
            <p className="text-gray-500">
              {filter === 'all' 
                ? 'No changes have been made to this case yet.'
                : `No changes found for the selected time period.`
              }
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {history.map((item, index) => (
              <div
                key={item.id}
                className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg border border-gray-200"
              >
                {/* Icon */}
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-lg">{getChangeIcon(item.table_name)}</span>
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-medium text-blue-600">
                        {getTableDisplayName(item.table_name)}
                      </span>
                      <span className="text-sm text-gray-500">•</span>
                      <span className="text-sm text-gray-700">
                        {getFieldDisplayName(item.table_name, item.field_name)}
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-2 text-xs text-gray-500">
                      <User className="w-3 h-3" />
                      <span>{item.changed_by}</span>
                      <Clock className="w-3 h-3 ml-2" />
                      <span>{new Date(item.changed_at).toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Change Details */}
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-xs text-gray-500 mb-1">Previous Value:</div>
                      <div className="p-2 bg-red-50 border border-red-200 rounded text-red-800">
                        {formatValue(item.old_value)}
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-xs text-gray-500 mb-1">New Value:</div>
                      <div className="p-2 bg-green-50 border border-green-200 rounded text-green-800">
                        {formatValue(item.new_value)}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {/* Load More Button */}
            {history.length >= 50 && (
              <div className="text-center pt-4">
                <button className="px-4 py-2 text-blue-600 hover:text-blue-800 text-sm font-medium">
                  Load More Changes
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default HistorySection;