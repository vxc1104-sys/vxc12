import React, { useState, useEffect } from 'react';
import { Plus, Trash2, DollarSign, Calculator, Search } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface FinanceItem {
  id: string;
  service_category: string | null;
  description: string;
  unit_type: string;
  supplier_cost: number;
  sales_price: number;
  currency: string;
  quantity: number;
  supplier: string | null;
}

interface Service {
  id: string;
  name: string;
  category: string;
  default_unit: string;
}

interface Supplier {
  id: string;
  name: string;
  contact_person: string | null;
}

interface FinanceSectionProps {
  caseId: string;
}

const FinanceSection: React.FC<FinanceSectionProps> = ({ caseId }) => {
  const [financeItems, setFinanceItems] = useState<FinanceItem[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFinanceItems();
    fetchMasterData();
  }, [caseId]);

  const fetchFinanceItems = async () => {
    try {
      const { data, error } = await supabase
        .from('finance_items')
        .select('*')
        .eq('case_id', caseId)
        .order('created_at');

      if (error) throw error;
      setFinanceItems(data || []);
    } catch (error) {
      console.error('Error fetching finance items:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchMasterData = async () => {
    try {
      // Fetch services (we'll create this table)
      const servicesData = [
        { id: '1', name: 'Ocean Freight', category: 'transport', default_unit: 'per container' },
        { id: '2', name: 'THC Origin', category: 'handling', default_unit: 'per container' },
        { id: '3', name: 'THC Destination', category: 'handling', default_unit: 'per container' },
        { id: '4', name: 'Documentation Fee', category: 'documentation', default_unit: 'per shipment' },
        { id: '5', name: 'ISPS Fee', category: 'security', default_unit: 'per container' },
        { id: '6', name: 'Customs Clearance', category: 'customs', default_unit: 'per shipment' },
        { id: '7', name: 'Trucking', category: 'transport', default_unit: 'per container' },
        { id: '8', name: 'Warehouse Handling', category: 'handling', default_unit: 'per ton' },
      ];
      setServices(servicesData);

      // Fetch suppliers
      const { data: suppliersData } = await supabase
        .from('customers')
        .select('id, name, contact_person')
        .order('name');
      setSuppliers(suppliersData || []);

      // Fetch customers
      const { data: customersData } = await supabase
        .from('customers')
        .select('id, name, contact_person')
        .order('name');
      setCustomers(customersData || []);
    } catch (error) {
      console.error('Error fetching master data:', error);
    }
  };

  const addNewItem = async () => {
    const newItem = {
      case_id: caseId,
      item_type: 'cost',
      service_category: 'misc',
      description: 'New Item',
      unit_type: 'per container',
      supplier_cost: 0,
      sales_price: 0,
      currency: 'EUR',
      quantity: 1,
      supplier: null,
    };

    try {
      const { data, error } = await supabase
        .from('finance_items')
        .insert([newItem])
        .select()
        .single();

      if (error) throw error;
      setFinanceItems([...financeItems, data]);
    } catch (error) {
      console.error('Error adding item:', error);
    }
  };

  const updateItem = async (id: string, field: string, value: any) => {
    try {
      const { error } = await supabase
        .from('finance_items')
        .update({ [field]: value })
        .eq('id', id);

      if (error) throw error;

      setFinanceItems(items =>
        items.map(item =>
          item.id === id ? { ...item, [field]: value } : item
        )
      );
    } catch (error) {
      console.error('Error updating item:', error);
    }
  };

  const deleteItem = async (id: string) => {
    try {
      const { error } = await supabase
        .from('finance_items')
        .delete()
        .eq('id', id);

      if (error) throw error;
      setFinanceItems(items => items.filter(item => item.id !== id));
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  const ServiceSelector: React.FC<{
    value: string;
    onChange: (value: string) => void;
    onServiceSelect: (service: Service) => void;
  }> = ({ value, onChange, onServiceSelect }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');

    const filteredServices = services.filter(service =>
      service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      service.category.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
      <div className="relative">
        <div className="flex">
          <input
            type="text"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onFocus={() => setIsOpen(true)}
            className="flex-1 px-2 py-1 border border-gray-300 rounded-l text-xs focus:ring-1 focus:ring-blue-500"
            placeholder="Type or select service..."
          />
          <button
            type="button"
            onClick={() => setIsOpen(!isOpen)}
            className="px-2 border border-l-0 border-gray-300 rounded-r hover:bg-gray-50"
          >
            <Search className="w-3 h-3" />
          </button>
        </div>

        {isOpen && (
          <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded shadow-lg max-h-48 overflow-y-auto">
            <div className="p-2 border-b">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search services..."
                className="w-full px-2 py-1 text-xs border border-gray-300 rounded"
              />
            </div>
            {filteredServices.map(service => (
              <button
                key={service.id}
                type="button"
                onClick={() => {
                  onServiceSelect(service);
                  setIsOpen(false);
                  setSearchTerm('');
                }}
                className="w-full text-left px-3 py-2 hover:bg-blue-50 text-xs"
              >
                <div className="font-medium">{service.name}</div>
                <div className="text-gray-500">{service.category} • {service.default_unit}</div>
              </button>
            ))}
          </div>
        )}
      </div>
    );
  };

  const SupplierSelector: React.FC<{
    value: string;
    onChange: (value: string) => void;
  }> = ({ value, onChange }) => {
    return (
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-2 py-1 border border-gray-300 rounded text-xs focus:ring-1 focus:ring-blue-500"
      >
        <option value="">Select supplier...</option>
        {suppliers.map(supplier => (
          <option key={supplier.id} value={supplier.name}>
            {supplier.name}
          </option>
        ))}
      </select>
    );
  };

  const calculateTotals = () => {
    const totalCost = financeItems.reduce((sum, item) => sum + (item.supplier_cost * item.quantity), 0);
    const totalRevenue = financeItems.reduce((sum, item) => sum + (item.sales_price * item.quantity), 0);
    const totalProfit = totalRevenue - totalCost;
    const marginPercent = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;

    return { totalCost, totalRevenue, totalProfit, marginPercent };
  };

  const { totalCost, totalRevenue, totalProfit, marginPercent } = calculateTotals();

  if (loading) {
    return <div className="p-6">Loading...</div>;
  }

  return (
    <div className="flex-1 bg-white overflow-hidden flex flex-col">
      {/* Header */}
      <div className="bg-purple-50 border-b border-purple-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-purple-800 flex items-center">
            <DollarSign className="w-5 h-5 mr-2" />
            Finanzen
          </h2>
          <button
            onClick={addNewItem}
            className="flex items-center px-3 py-2 bg-purple-600 text-white rounded hover:bg-purple-700 text-sm"
          >
            <Plus className="w-4 h-4 mr-1" />
            Zeile hinzufügen
          </button>
        </div>
      </div>

      {/* Finance Table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b sticky top-0">
            <tr>
              <th className="text-left px-3 py-2 font-medium text-gray-700 w-8"></th>
              <th className="text-left px-3 py-2 font-medium text-gray-700">Leistung / Gebühr</th>
              <th className="text-left px-3 py-2 font-medium text-gray-700">Zusatztext</th>
              <th className="text-left px-3 py-2 font-medium text-gray-700 bg-yellow-50">Einkaufspreis</th>
              <th className="text-left px-3 py-2 font-medium text-gray-700">Lieferant</th>
              <th className="text-left px-3 py-2 font-medium text-gray-700 bg-green-50">Verkaufspreis</th>
              <th className="text-left px-3 py-2 font-medium text-gray-700">Kunde</th>
              <th className="text-left px-3 py-2 font-medium text-gray-700 bg-blue-50">Profit</th>
              <th className="w-8"></th>
            </tr>
          </thead>
          <tbody>
            {financeItems.map((item, index) => {
              const profit = (item.sales_price * item.quantity) - (item.supplier_cost * item.quantity);
              const isProfit = profit > 0;
              
              return (
                <tr key={item.id} className={`border-b hover:bg-gray-50 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-25'}`}>
                  <td className="px-3 py-2">
                    <input
                      type="checkbox"
                      className="rounded border-gray-300"
                    />
                  </td>
                  
                  <td className="px-3 py-2">
                    <ServiceSelector
                      value={item.description}
                      onChange={(value) => updateItem(item.id, 'description', value)}
                      onServiceSelect={(service) => {
                        updateItem(item.id, 'description', service.name);
                        updateItem(item.id, 'service_category', service.category);
                        updateItem(item.id, 'unit_type', service.default_unit);
                      }}
                    />
                  </td>
                  
                  <td className="px-3 py-2">
                    <input
                      type="text"
                      value={item.description}
                      onChange={(e) => updateItem(item.id, 'description', e.target.value)}
                      className="w-full px-2 py-1 border border-gray-300 rounded text-xs focus:ring-1 focus:ring-blue-500"
                    />
                  </td>
                  
                  <td className="px-3 py-2 bg-yellow-50">
                    <div className="flex items-center space-x-1">
                      <input
                        type="number"
                        value={item.supplier_cost}
                        onChange={(e) => updateItem(item.id, 'supplier_cost', parseFloat(e.target.value) || 0)}
                        className="w-20 px-2 py-1 border border-gray-300 rounded text-xs text-right focus:ring-1 focus:ring-blue-500"
                        step="0.01"
                      />
                      <span className="text-xs text-gray-500">{item.currency}</span>
                    </div>
                  </td>
                  
                  <td className="px-3 py-2">
                    <SupplierSelector
                      value={item.supplier || ''}
                      onChange={(value) => updateItem(item.id, 'supplier', value)}
                    />
                  </td>
                  
                  <td className="px-3 py-2 bg-green-50">
                    <div className="flex items-center space-x-1">
                      <input
                        type="number"
                        value={item.sales_price}
                        onChange={(e) => updateItem(item.id, 'sales_price', parseFloat(e.target.value) || 0)}
                        className="w-20 px-2 py-1 border border-gray-300 rounded text-xs text-right focus:ring-1 focus:ring-blue-500"
                        step="0.01"
                      />
                      <span className="text-xs text-gray-500">{item.currency}</span>
                    </div>
                  </td>
                  
                  <td className="px-3 py-2">
                    <select
                      className="w-full px-2 py-1 border border-gray-300 rounded text-xs focus:ring-1 focus:ring-blue-500"
                    >
                      <option value="">Select customer...</option>
                      {customers.map(customer => (
                        <option key={customer.id} value={customer.name}>
                          {customer.name}
                        </option>
                      ))}
                    </select>
                  </td>
                  
                  <td className={`px-3 py-2 ${isProfit ? 'bg-green-50' : 'bg-red-50'}`}>
                    <span className={`text-xs font-medium ${isProfit ? 'text-green-700' : 'text-red-700'}`}>
                      {profit.toFixed(2)} {item.currency}
                    </span>
                  </td>
                  
                  <td className="px-3 py-2">
                    <button
                      onClick={() => deleteItem(item.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Totals Summary */}
      <div className="border-t bg-gray-50 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <div className="text-sm">
              <span className="text-gray-600">Total Cost: </span>
              <span className="font-semibold text-red-700">{totalCost.toFixed(2)} EUR</span>
            </div>
            <div className="text-sm">
              <span className="text-gray-600">Total Revenue: </span>
              <span className="font-semibold text-green-700">{totalRevenue.toFixed(2)} EUR</span>
            </div>
            <div className="text-sm">
              <span className="text-gray-600">Total Profit: </span>
              <span className={`font-semibold ${totalProfit >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                {totalProfit.toFixed(2)} EUR
              </span>
            </div>
            <div className="text-sm">
              <span className="text-gray-600">Margin: </span>
              <span className={`font-semibold ${marginPercent >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                {marginPercent.toFixed(1)}%
              </span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Calculator className="w-4 h-4 text-gray-400" />
            <span className="text-sm text-gray-500">{financeItems.length} positions</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinanceSection;