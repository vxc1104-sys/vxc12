import React, { useState, useEffect } from 'react';
import { Settings, Save, RotateCcw, AlertTriangle } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface CaseSettings {
  id: string;
  status: string;
  service_type: string;
  incoterms: string;
  internal_comments: string | null;
}

interface SettingsSectionProps {
  caseId: string;
}

const SettingsSection: React.FC<SettingsSectionProps> = ({ caseId }) => {
  const [settings, setSettings] = useState<CaseSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const [statusHistory, setStatusHistory] = useState<any[]>([]);

  useEffect(() => {
    fetchSettings();
    fetchStatusHistory();
  }, [caseId]);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('cases')
        .select('id, status, service_type, incoterms, internal_comments')
        .eq('id', caseId)
        .single();

      if (error) throw error;
      setSettings(data);
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchStatusHistory = async () => {
    try {
      const { data, error } = await supabase
        .from('case_status_history')
        .select('*')
        .eq('case_id', caseId)
        .order('changed_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      setStatusHistory(data || []);
    } catch (error) {
      console.error('Error fetching status history:', error);
    }
  };

  const handleFieldChange = (field: keyof CaseSettings, value: any) => {
    if (!settings) return;
    
    // Track status changes
    if (field === 'status' && settings.status !== value) {
      recordStatusChange(settings.status, value);
    }
    
    setSettings(prev => prev ? { ...prev, [field]: value } : null);
    setHasChanges(true);
  };

  const recordStatusChange = async (oldStatus: string, newStatus: string) => {
    try {
      await supabase
        .from('case_status_history')
        .insert([{
          case_id: caseId,
          old_status: oldStatus,
          new_status: newStatus,
          changed_by: 'user',
          notes: `Status changed from ${oldStatus} to ${newStatus}`
        }]);
      
      fetchStatusHistory();
    } catch (error) {
      console.error('Error recording status change:', error);
    }
  };

  const saveSettings = async () => {
    if (!settings) return;
    
    setSaving(true);
    try {
      const { error } = await supabase
        .from('cases')
        .update({
          status: settings.status,
          service_type: settings.service_type,
          incoterms: settings.incoterms,
          internal_comments: settings.internal_comments,
          updated_at: new Date().toISOString()
        })
        .eq('id', caseId);

      if (error) throw error;
      setHasChanges(false);
    } catch (error) {
      console.error('Error saving settings:', error);
    } finally {
      setSaving(false);
    }
  };

  const resetSettings = () => {
    fetchSettings();
    setHasChanges(false);
  };

  const archiveCase = async () => {
    if (!confirm('Are you sure you want to archive this case? This action cannot be undone.')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('cases')
        .update({ status: 'archived' })
        .eq('id', caseId);

      if (error) throw error;
      setSettings(prev => prev ? { ...prev, status: 'archived' } : null);
    } catch (error) {
      console.error('Error archiving case:', error);
    }
  };

  if (loading || !settings) {
    return <div className="p-6">Loading settings...</div>;
  }

  return (
    <div className="flex-1 bg-white overflow-y-auto">
      {/* Header */}
      <div className="bg-teal-50 border-b border-teal-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-teal-800 flex items-center">
            <Settings className="w-5 h-5 mr-2" />
            Einstellungen
          </h2>
          
          {hasChanges && (
            <div className="flex items-center space-x-2">
              <button
                onClick={resetSettings}
                className="flex items-center px-3 py-2 text-gray-600 hover:text-gray-800 text-sm"
              >
                <RotateCcw className="w-4 h-4 mr-1" />
                Reset
              </button>
              
              <button
                onClick={saveSettings}
                disabled={saving}
                className="flex items-center px-4 py-2 bg-teal-600 text-white rounded hover:bg-teal-700 text-sm disabled:opacity-50"
              >
                <Save className="w-4 h-4 mr-1" />
                {saving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="p-6 space-y-8">
        {/* Case Status */}
        <div className="bg-blue-50 p-6 rounded-lg">
          <h3 className="text-lg font-semibold text-blue-800 mb-4">Case Status</h3>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Current Status
              </label>
              <select
                value={settings.status}
                onChange={(e) => handleFieldChange('status', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="draft">Draft</option>
                <option value="active">Active</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
                <option value="on_hold">On Hold</option>
                <option value="archived">Archived</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Service Type
              </label>
              <select
                value={settings.service_type}
                onChange={(e) => handleFieldChange('service_type', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="FCL">FCL (Full Container Load)</option>
                <option value="LCL">LCL (Less Container Load)</option>
                <option value="Air">Air Freight</option>
                <option value="Road">Road Transport</option>
                <option value="Rail">Rail Transport</option>
              </select>
            </div>
          </div>
          
          {/* Status History */}
          {statusHistory.length > 0 && (
            <div className="mt-6 pt-6 border-t border-blue-200">
              <h4 className="text-sm font-medium text-blue-700 mb-3">Recent Status Changes</h4>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {statusHistory.map((change, index) => (
                  <div key={change.id} className="text-xs text-blue-600 bg-blue-100 p-2 rounded">
                    <span className="font-medium">{change.old_status}</span> → <span className="font-medium">{change.new_status}</span>
                    <span className="ml-2 text-blue-500">
                      {new Date(change.changed_at).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Trade Terms */}
        <div className="bg-green-50 p-6 rounded-lg">
          <h3 className="text-lg font-semibold text-green-800 mb-4">Trade Terms</h3>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Incoterms
            </label>
            <select
              value={settings.incoterms}
              onChange={(e) => handleFieldChange('incoterms', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
            >
              <option value="EXW">EXW - Ex Works</option>
              <option value="FCA">FCA - Free Carrier</option>
              <option value="CPT">CPT - Carriage Paid To</option>
              <option value="CIP">CIP - Carriage and Insurance Paid To</option>
              <option value="DAP">DAP - Delivered at Place</option>
              <option value="DPU">DPU - Delivered at Place Unloaded</option>
              <option value="DDP">DDP - Delivered Duty Paid</option>
              <option value="FAS">FAS - Free Alongside Ship</option>
              <option value="FOB">FOB - Free on Board</option>
              <option value="CFR">CFR - Cost and Freight</option>
              <option value="CIF">CIF - Cost, Insurance and Freight</option>
            </select>
          </div>
        </div>

        {/* Internal Notes */}
        <div className="bg-yellow-50 p-6 rounded-lg">
          <h3 className="text-lg font-semibold text-yellow-800 mb-4">Internal Notes</h3>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Comments (Internal Use Only)
            </label>
            <textarea
              value={settings.internal_comments || ''}
              onChange={(e) => handleFieldChange('internal_comments', e.target.value)}
              rows={6}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 resize-none"
              placeholder="Add internal comments, notes, or special instructions..."
            />
          </div>
        </div>

        {/* Danger Zone */}
        <div className="bg-red-50 border border-red-200 p-6 rounded-lg">
          <h3 className="text-lg font-semibold text-red-800 mb-4 flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2" />
            Danger Zone
          </h3>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-red-700 mb-2">Archive Case</h4>
              <p className="text-sm text-red-600 mb-3">
                Archiving a case will move it to the archived status and hide it from active case lists. 
                This action can be reversed by changing the status back.
              </p>
              <button
                onClick={archiveCase}
                disabled={settings.status === 'archived'}
                className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {settings.status === 'archived' ? 'Already Archived' : 'Archive Case'}
              </button>
            </div>
          </div>
        </div>

        {/* Save Changes Bar */}
        {hasChanges && (
          <div className="fixed bottom-6 right-6 bg-white border border-gray-300 rounded-lg shadow-lg p-4">
            <div className="flex items-center space-x-3">
              <div className="text-sm text-gray-600">You have unsaved changes</div>
              <button
                onClick={resetSettings}
                className="px-3 py-1 text-gray-600 hover:text-gray-800 text-sm"
              >
                Discard
              </button>
              <button
                onClick={saveSettings}
                disabled={saving}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SettingsSection;