import React, { useState, useEffect } from 'react';
import { X, FileText, Download, Eye, Save } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface DocumentTemplate {
  id: string;
  template_name: string;
  template_type: string;
  template_content: string;
}

interface CaseData {
  case_number: string;
  customer_name?: string;
  customer_reference?: string;
  service_type?: string;
  vessel_name?: string;
  carrier?: string;
  origin_port?: string;
  destination_port?: string;
  loading_port?: string;
  discharge_port?: string;
  pickup_date?: string;
  delivery_date?: string;
  standard_closing?: string;
  vwm_closing?: string;
  cy_closing?: string;
  container_type?: string;
  voyage?: string;
}

interface DocumentCreationWindowProps {
  isOpen: boolean;
  onClose: () => void;
  caseId: string;
  caseData: CaseData;
}

const DocumentCreationWindow: React.FC<DocumentCreationWindowProps> = ({
  isOpen,
  onClose,
  caseId,
  caseData
}) => {
  const [templates, setTemplates] = useState<DocumentTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<DocumentTemplate | null>(null);
  const [documentContent, setDocumentContent] = useState('');
  const [documentName, setDocumentName] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);

  useEffect(() => {
    if (isOpen) {
      fetchTemplates();
    }
  }, [isOpen]);

  const fetchTemplates = async () => {
    try {
      const { data, error } = await supabase
        .from('document_templates')
        .select('*')
        .eq('is_active', true)
        .order('template_name');

      if (error) throw error;
      setTemplates(data || []);
    } catch (error) {
      console.error('Error fetching templates:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleTemplateSelect = (template: DocumentTemplate) => {
    setSelectedTemplate(template);
    setDocumentName(`${template.template_name} - ${caseData.case_number}`);
    
    // Replace placeholders with actual case data
    let content = template.template_content;
    
    // Replace all placeholders
    const replacements: Record<string, string> = {
      '{{case_number}}': caseData.case_number || '',
      '{{customer_name}}': caseData.customer_name || '',
      '{{customer_reference}}': caseData.customer_reference || '',
      '{{service_type}}': caseData.service_type || '',
      '{{vessel_name}}': caseData.vessel_name || '',
      '{{carrier}}': caseData.carrier || '',
      '{{origin_port}}': caseData.origin_port || '',
      '{{destination_port}}': caseData.destination_port || '',
      '{{loading_port}}': caseData.loading_port || '',
      '{{discharge_port}}': caseData.discharge_port || '',
      '{{pickup_date}}': caseData.pickup_date ? new Date(caseData.pickup_date).toLocaleDateString() : '',
      '{{delivery_date}}': caseData.delivery_date ? new Date(caseData.delivery_date).toLocaleDateString() : '',
      '{{standard_closing}}': caseData.standard_closing ? new Date(caseData.standard_closing).toLocaleDateString() : '',
      '{{vwm_closing}}': caseData.vwm_closing ? new Date(caseData.vwm_closing).toLocaleDateString() : '',
      '{{cy_closing}}': caseData.cy_closing ? new Date(caseData.cy_closing).toLocaleDateString() : '',
      '{{container_type}}': caseData.container_type || '',
      '{{voyage}}': caseData.voyage || ''
    };

    Object.entries(replacements).forEach(([placeholder, value]) => {
      content = content.replace(new RegExp(placeholder, 'g'), value);
    });

    setDocumentContent(content);
  };

  const handleSaveDocument = async () => {
    if (!selectedTemplate || !documentName.trim()) {
      alert('Please select a template and enter a document name');
      return;
    }

    setSaving(true);
    try {
      const { error } = await supabase
        .from('generated_documents')
        .insert([{
          case_id: caseId,
          template_id: selectedTemplate.id,
          document_name: documentName,
          document_content: documentContent,
          document_type: selectedTemplate.template_type,
          generated_by: 'user'
        }]);

      if (error) throw error;
      
      alert('Document saved successfully!');
      onClose();
    } catch (error) {
      console.error('Error saving document:', error);
      alert('Error saving document. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleDownload = () => {
    const blob = new Blob([documentContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${documentName}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-6xl mx-4 max-h-[90vh] overflow-hidden">
        {/* Window Title Bar */}
        <div className="bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <FileText className="w-5 h-5" />
            <span className="font-medium">Create Document - {caseData.case_number}</span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-6 bg-red-500 hover:bg-red-600 rounded flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex h-full" style={{ height: 'calc(90vh - 60px)' }}>
          {/* Left Panel - Template Selection */}
          <div className="w-80 bg-gray-50 border-r border-gray-200 p-4">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Document Templates</h3>
            
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin w-8 h-8 border-4 border-green-600 border-t-transparent rounded-full mx-auto mb-4"></div>
                <p className="text-gray-600">Loading templates...</p>
              </div>
            ) : (
              <div className="space-y-2">
                {templates.map(template => (
                  <button
                    key={template.id}
                    onClick={() => handleTemplateSelect(template)}
                    className={`w-full text-left p-3 rounded-lg border transition-colors ${
                      selectedTemplate?.id === template.id
                        ? 'bg-green-100 border-green-500 text-green-800'
                        : 'bg-white border-gray-200 hover:bg-gray-50'
                    }`}
                  >
                    <div className="font-medium">{template.template_name}</div>
                    <div className="text-sm text-gray-500 capitalize">
                      {template.template_type.replace('_', ' ')}
                    </div>
                  </button>
                ))}
              </div>
            )}

            {selectedTemplate && (
              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Document Name
                    </label>
                    <input
                      type="text"
                      value={documentName}
                      onChange={(e) => setDocumentName(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    />
                  </div>

                  <div className="flex space-x-2">
                    <button
                      onClick={() => setPreviewMode(!previewMode)}
                      className="flex items-center px-3 py-2 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 text-sm"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      {previewMode ? 'Edit' : 'Preview'}
                    </button>

                    <button
                      onClick={handleDownload}
                      className="flex items-center px-3 py-2 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 text-sm"
                    >
                      <Download className="w-4 h-4 mr-1" />
                      Download
                    </button>
                  </div>

                  <button
                    onClick={handleSaveDocument}
                    disabled={saving || !documentName.trim()}
                    className="w-full flex items-center justify-center px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    {saving ? 'Saving...' : 'Save Document'}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Right Panel - Document Editor/Preview */}
          <div className="flex-1 flex flex-col">
            {selectedTemplate ? (
              <>
                <div className="bg-white border-b border-gray-200 px-4 py-2">
                  <h4 className="font-medium text-gray-800">{selectedTemplate.template_name}</h4>
                </div>

                <div className="flex-1 p-4">
                  {previewMode ? (
                    <div 
                      className="w-full h-full border border-gray-300 rounded bg-white p-4 overflow-auto"
                      dangerouslySetInnerHTML={{ __html: documentContent }}
                    />
                  ) : (
                    <textarea
                      value={documentContent}
                      onChange={(e) => setDocumentContent(e.target.value)}
                      className="w-full h-full border border-gray-300 rounded p-4 font-mono text-sm resize-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
                      placeholder="Document content will appear here..."
                    />
                  )}
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Select a Template</h3>
                  <p className="text-gray-500">Choose a document template from the left panel to get started</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentCreationWindow;