import { useState, useEffect, useCallback } from 'react';

export type AutoSaveStatus = 'idle' | 'saving' | 'saved';

interface UseAutoSaveOptions {
  delay?: number; // Delay in milliseconds before saving
  onSave: () => Promise<void>;
}

export const useAutoSave = ({ delay = 1000, onSave }: UseAutoSaveOptions) => {
  const [status, setStatus] = useState<AutoSaveStatus>('idle');
  const [pendingChanges, setPendingChanges] = useState(false);

  const triggerSave = useCallback(() => {
    setPendingChanges(true);
  }, []);

  useEffect(() => {
    if (!pendingChanges) return;

    const timeoutId = setTimeout(async () => {
      setStatus('saving');
      try {
        await onSave();
        setStatus('saved');
        setPendingChanges(false);
        
        // Reset to idle after showing saved status
        setTimeout(() => {
          setStatus('idle');
        }, 2000);
      } catch (error) {
        console.error('Auto-save failed:', error);
        setStatus('idle');
        setPendingChanges(false);
      }
    }, delay);

    return () => clearTimeout(timeoutId);
  }, [pendingChanges, delay, onSave]);

  return {
    status,
    triggerSave
  };
};