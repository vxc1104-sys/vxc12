import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseKey);

export type Database = {
  public: {
    Tables: {
      customers: {
        Row: {
          id: string;
          company_name: string;
          customer_code: string | null;
          address_line1: string | null;
          address_line2: string | null;
          city: string | null;
          postal_code: string | null;
          country: string | null;
          contact_person_primary: string | null;
          contact_person_secondary: string | null;
          phone_primary: string | null;
          phone_secondary: string | null;
          email_primary: string | null;
          email_secondary: string | null;
          website: string | null;
          opening_hours: string | null;
          internal_notes: string | null;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['customers']['Row'], 'id' | 'created_at' | 'updated_at' | 'is_active'>;
        Update: Partial<Database['public']['Tables']['customers']['Insert']>;
      };
      ports: {
        Row: {
          id: string;
          port_code: string;
          port_name: string;
          city: string;
          country: string;
          country_code: string | null;
          region: string | null;
          latitude: number | null;
          longitude: number | null;
          is_major_port: boolean;
          is_active: boolean;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['ports']['Row'], 'id' | 'created_at' | 'is_major_port' | 'is_active'>;
        Update: Partial<Database['public']['Tables']['ports']['Insert']>;
      };
      suppliers: {
        Row: {
          id: string;
          company_name: string;
          supplier_code: string | null;
          address_line1: string | null;
          address_line2: string | null;
          city: string | null;
          postal_code: string | null;
          country: string | null;
          contact_person: string | null;
          phone: string | null;
          email: string | null;
          website: string | null;
          service_categories: string[] | null;
          payment_terms: string | null;
          internal_notes: string | null;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['suppliers']['Row'], 'id' | 'created_at' | 'updated_at' | 'is_active'>;
        Update: Partial<Database['public']['Tables']['suppliers']['Insert']>;
      };
      services: {
        Row: {
          id: string;
          service_name: string;
          service_code: string | null;
          category: string;
          subcategory: string | null;
          default_unit: string;
          description: string | null;
          is_standard: boolean;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['services']['Row'], 'id' | 'created_at' | 'updated_at' | 'is_standard' | 'is_active'>;
        Update: Partial<Database['public']['Tables']['services']['Insert']>;
      };
      cases: {
        Row: {
          id: string;
          case_number: string;
          case_type: string;
          customer_id: string | null;
          status: string;
          reference: string | null;
          booking_code: string | null;
          purchase_contract: string | null;
          sales_contract: string | null;
          service_type: string;
          incoterms: string;
          direction: string;
          direction: string;
          customer_reference: string | null;
          vessel_name: string | null;
          carrier: string | null;
          loading_port_id: string | null;
          loading_terminal: string | null;
          pickup_date: string | null;
          delivery_date: string | null;
          standard_closing: string | null;
          vwm_closing: string | null;
          cy_closing: string | null;
          dock_closing_carrier: string | null;
          dock_closing_customer: string | null;
          validity_from: string | null;
          validity_to: string | null;
          departure_date: string | null;
          arrival_date: string | null;
          internal_comments: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['cases']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['cases']['Insert']>;
      };
      finance_items: {
        Row: {
          id: string;
          case_id: string;
          item_type: string;
          service_category: string | null;
          description: string;
          unit_type: string;
          supplier_cost: number;
          sales_price: number;
          currency: string;
          quantity: number;
          supplier: string | null;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['finance_items']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['finance_items']['Insert']>;
      };
    };
  };
};