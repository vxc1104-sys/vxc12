/*
  # Add direction column to cases table

  1. Changes
    - Add `direction` column to `cases` table
    - Set default value to 'export' for existing records
    - Make column NOT NULL

  2. Security
    - No changes to RLS policies needed
*/

-- Add direction column to cases table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'cases' AND column_name = 'direction'
  ) THEN
    ALTER TABLE cases ADD COLUMN direction text DEFAULT 'export' NOT NULL;
  END IF;
END $$;