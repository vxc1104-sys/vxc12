/*
  # Fix RLS policy for cases table

  1. Security Changes
    - Add policy to allow anonymous users to insert cases
    - Add policy to allow anonymous users to select cases
    - Keep existing authenticated user policies
*/

-- Allow anonymous users to insert cases
CREATE POLICY "Anonymous users can create cases"
  ON cases
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Allow anonymous users to select cases
CREATE POLICY "Anonymous users can view cases"
  ON cases
  FOR SELECT
  TO anon
  USING (true);

-- Allow anonymous users to update cases
CREATE POLICY "Anonymous users can update cases"
  ON cases
  FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

-- Allow anonymous users to delete cases
CREATE POLICY "Anonymous users can delete cases"
  ON cases
  FOR DELETE
  TO anon
  USING (true);