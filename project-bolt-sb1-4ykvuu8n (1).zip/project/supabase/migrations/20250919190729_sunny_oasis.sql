/*
  # Logistics Management System Database Schema

  1. New Tables
    - `customers` - Customer information and contacts
    - `cases` - Main bookings and quotations
    - `goods` - Cargo details for each case
    - `routes` - Origin, destination, and route information
    - `finance_items` - Individual cost and revenue line items
    - `documents` - Uploaded documents linked to cases
    - `change_history` - Audit trail for all modifications
    - `ports` - Master data for ports and locations

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their data

  3. Key Features
    - Comprehensive freight forwarding data model
    - Automatic profit calculations
    - Document management
    - Full audit trail
    - Master data management
*/

-- Customers table
CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text UNIQUE,
  address text,
  contact_person text,
  email text,
  phone text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Ports master data
CREATE TABLE IF NOT EXISTS ports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  country text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Main cases (bookings/quotations)
CREATE TABLE IF NOT EXISTS cases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_number text UNIQUE NOT NULL,
  case_type text NOT NULL DEFAULT 'booking', -- booking or quotation
  customer_id uuid REFERENCES customers(id),
  status text DEFAULT 'draft',
  reference text,
  booking_code text,
  purchase_contract text,
  sales_contract text,
  service_type text DEFAULT 'FCL',
  incoterms text DEFAULT 'FOB',
  validity_from date,
  validity_to date,
  departure_date date,
  arrival_date date,
  internal_comments text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Goods details
CREATE TABLE IF NOT EXISTS goods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES cases(id) ON DELETE CASCADE,
  description text,
  hs_code text,
  weight_kg numeric(10,2),
  volume_cbm numeric(10,2),
  packages integer,
  packaging_type text,
  container_type text,
  container_count integer DEFAULT 1,
  created_at timestamptz DEFAULT now()
);

-- Route information
CREATE TABLE IF NOT EXISTS routes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES cases(id) ON DELETE CASCADE,
  origin_port_id uuid REFERENCES ports(id),
  destination_port_id uuid REFERENCES ports(id),
  loading_port_id uuid REFERENCES ports(id),
  discharge_port_id uuid REFERENCES ports(id),
  carrier text,
  shipping_line text,
  vessel text,
  voyage text,
  created_at timestamptz DEFAULT now()
);

-- Finance line items
CREATE TABLE IF NOT EXISTS finance_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES cases(id) ON DELETE CASCADE,
  item_type text NOT NULL, -- 'cost' or 'revenue'
  service_category text, -- precarriage, ocean_freight, surcharge, etc.
  description text NOT NULL,
  unit_type text DEFAULT 'per container',
  supplier_cost numeric(10,2) DEFAULT 0,
  sales_price numeric(10,2) DEFAULT 0,
  currency text DEFAULT 'EUR',
  quantity numeric(10,2) DEFAULT 1,
  supplier text,
  created_at timestamptz DEFAULT now()
);

-- Documents
CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES cases(id) ON DELETE CASCADE,
  file_name text NOT NULL,
  file_url text NOT NULL,
  file_type text,
  document_category text, -- booking_confirmation, bill_of_lading, invoice, etc.
  uploaded_at timestamptz DEFAULT now()
);

-- Change history
CREATE TABLE IF NOT EXISTS change_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES cases(id) ON DELETE CASCADE,
  table_name text NOT NULL,
  record_id uuid NOT NULL,
  field_name text NOT NULL,
  old_value text,
  new_value text,
  changed_by text DEFAULT 'system',
  changed_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE ports ENABLE ROW LEVEL SECURITY;
ALTER TABLE cases ENABLE ROW LEVEL SECURITY;
ALTER TABLE goods ENABLE ROW LEVEL SECURITY;
ALTER TABLE routes ENABLE ROW LEVEL SECURITY;
ALTER TABLE finance_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE change_history ENABLE ROW LEVEL SECURITY;

-- RLS Policies (allowing all operations for authenticated users)
CREATE POLICY "Users can manage customers"
  ON customers FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can view ports"
  ON ports FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage cases"
  ON cases FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can manage goods"
  ON goods FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can manage routes"
  ON routes FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can manage finance_items"
  ON finance_items FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can manage documents"
  ON documents FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can view change_history"
  ON change_history FOR SELECT
  TO authenticated
  USING (true);

-- Insert some sample data
INSERT INTO customers (name, code, contact_person, email) VALUES
  ('Khedivial Marine Logistics', 'KML', 'Hala El-Kodsi', 'hala@kml.com'),
  ('Yang Ming Shipping', 'YML', 'Yang Ming Line', 'info@yangming.com'),
  ('Alexandria EGALY', 'EGALY', 'Port Manager', 'port@egaly.com');

INSERT INTO ports (code, name, country) VALUES
  ('DEHAM', 'Hamburg', 'Germany'),
  ('SGSIN', 'Singapore', 'Singapore'),
  ('EGALY', 'Alexandria', 'Egypt'),
  ('USNYC', 'New York', 'United States'),
  ('CNSHA', 'Shanghai', 'China');

-- Sample case
INSERT INTO cases (case_number, customer_id, reference, booking_code, service_type, incoterms, status) 
VALUES (
  'HBSQ24120616',
  (SELECT id FROM customers WHERE code = 'KML'),
  'Sea FCL Export Angebot',
  '200V, 400V',
  'FCL',
  'FOB',
  'active'
);