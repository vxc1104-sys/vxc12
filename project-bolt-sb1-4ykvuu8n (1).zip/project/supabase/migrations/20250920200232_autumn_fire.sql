/*
  # Complete Master Data System

  1. New Tables
    - `customers` - Customer master data with full contact information
    - `ports` - World ports database with major ports pre-filled
    - `suppliers` - Supplier master data
    - `services` - Service/fee master data with categories
    - `document_templates` - Document templates for generation
    - `generated_documents` - Generated documents linked to cases
    - `case_status_history` - Track status changes over time

  2. Enhanced Tables
    - Update `cases` table with additional booking/quotation fields
    - Add proper foreign key relationships

  3. Security
    - Enable RLS on all tables
    - Add policies for authenticated and anonymous users
*/

-- Create customers table with full contact information
CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL,
  customer_code text UNIQUE,
  address_line1 text,
  address_line2 text,
  city text,
  postal_code text,
  country text,
  contact_person_primary text,
  contact_person_secondary text,
  phone_primary text,
  phone_secondary text,
  email_primary text,
  email_secondary text,
  website text,
  opening_hours text,
  internal_notes text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create ports table with major world ports
CREATE TABLE IF NOT EXISTS ports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  port_code text UNIQUE NOT NULL,
  port_name text NOT NULL,
  city text NOT NULL,
  country text NOT NULL,
  country_code text,
  region text,
  latitude decimal(10,8),
  longitude decimal(11,8),
  is_major_port boolean DEFAULT false,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create suppliers table
CREATE TABLE IF NOT EXISTS suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL,
  supplier_code text UNIQUE,
  address_line1 text,
  address_line2 text,
  city text,
  postal_code text,
  country text,
  contact_person text,
  phone text,
  email text,
  website text,
  service_categories text[], -- Array of service categories they provide
  payment_terms text,
  internal_notes text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create enhanced services table
CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_name text NOT NULL,
  service_code text UNIQUE,
  category text NOT NULL, -- transport, handling, documentation, customs, etc.
  subcategory text,
  default_unit text DEFAULT 'per container',
  description text,
  is_standard boolean DEFAULT false, -- Standard services appear first in lists
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create document templates table
CREATE TABLE IF NOT EXISTS document_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_name text NOT NULL,
  template_type text NOT NULL, -- transport_order, booking_confirmation, invoice, etc.
  template_content text NOT NULL, -- HTML template with placeholders
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create generated documents table
CREATE TABLE IF NOT EXISTS generated_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES cases(id) ON DELETE CASCADE,
  template_id uuid REFERENCES document_templates(id),
  document_name text NOT NULL,
  document_content text NOT NULL, -- Final HTML/PDF content
  document_type text NOT NULL,
  generated_at timestamptz DEFAULT now(),
  generated_by text DEFAULT 'system'
);

-- Create case status history table
CREATE TABLE IF NOT EXISTS case_status_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES cases(id) ON DELETE CASCADE,
  old_status text,
  new_status text NOT NULL,
  changed_by text DEFAULT 'system',
  changed_at timestamptz DEFAULT now(),
  notes text
);

-- Update cases table with additional fields for quotations vs bookings
DO $$
BEGIN
  -- Add quotation-specific fields
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cases' AND column_name = 'validity_from') THEN
    ALTER TABLE cases ADD COLUMN validity_from date;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cases' AND column_name = 'validity_to') THEN
    ALTER TABLE cases ADD COLUMN validity_to date;
  END IF;
  
  -- Add booking-specific fields
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cases' AND column_name = 'customer_reference') THEN
    ALTER TABLE cases ADD COLUMN customer_reference text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cases' AND column_name = 'vessel_name') THEN
    ALTER TABLE cases ADD COLUMN vessel_name text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cases' AND column_name = 'carrier') THEN
    ALTER TABLE cases ADD COLUMN carrier text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cases' AND column_name = 'loading_port_id') THEN
    ALTER TABLE cases ADD COLUMN loading_port_id uuid REFERENCES ports(id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cases' AND column_name = 'loading_terminal') THEN
    ALTER TABLE cases ADD COLUMN loading_terminal text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cases' AND column_name = 'pickup_date') THEN
    ALTER TABLE cases ADD COLUMN pickup_date timestamptz;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cases' AND column_name = 'delivery_date') THEN
    ALTER TABLE cases ADD COLUMN delivery_date timestamptz;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cases' AND column_name = 'standard_closing') THEN
    ALTER TABLE cases ADD COLUMN standard_closing timestamptz;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cases' AND column_name = 'vwm_closing') THEN
    ALTER TABLE cases ADD COLUMN vwm_closing timestamptz;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cases' AND column_name = 'cy_closing') THEN
    ALTER TABLE cases ADD COLUMN cy_closing timestamptz;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cases' AND column_name = 'dock_closing_carrier') THEN
    ALTER TABLE cases ADD COLUMN dock_closing_carrier timestamptz;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cases' AND column_name = 'dock_closing_customer') THEN
    ALTER TABLE cases ADD COLUMN dock_closing_customer timestamptz;
  END IF;
END $$;

-- Insert major world ports
INSERT INTO ports (port_code, port_name, city, country, country_code, region, is_major_port) VALUES
('DEHAM', 'Hamburg', 'Hamburg', 'Germany', 'DE', 'Europe', true),
('NLRTM', 'Rotterdam', 'Rotterdam', 'Netherlands', 'NL', 'Europe', true),
('CNSHA', 'Shanghai', 'Shanghai', 'China', 'CN', 'Asia', true),
('SGSIN', 'Singapore', 'Singapore', 'Singapore', 'SG', 'Asia', true),
('USLAX', 'Los Angeles', 'Los Angeles', 'United States', 'US', 'North America', true),
('USNYC', 'New York', 'New York', 'United States', 'US', 'North America', true),
('HKHKG', 'Hong Kong', 'Hong Kong', 'Hong Kong', 'HK', 'Asia', true),
('CNQIN', 'Qingdao', 'Qingdao', 'China', 'CN', 'Asia', true),
('CNNBO', 'Ningbo', 'Ningbo', 'China', 'CN', 'Asia', true),
('KRPUS', 'Busan', 'Busan', 'South Korea', 'KR', 'Asia', true),
('AEDXB', 'Dubai', 'Dubai', 'United Arab Emirates', 'AE', 'Middle East', true),
('BEANR', 'Antwerp', 'Antwerp', 'Belgium', 'BE', 'Europe', true),
('GBFXT', 'Felixstowe', 'Felixstowe', 'United Kingdom', 'GB', 'Europe', true),
('ITGOA', 'Genoa', 'Genoa', 'Italy', 'IT', 'Europe', true),
('ESLPA', 'Las Palmas', 'Las Palmas', 'Spain', 'ES', 'Europe', true),
('USOAK', 'Oakland', 'Oakland', 'United States', 'US', 'North America', true),
('USLGB', 'Long Beach', 'Long Beach', 'United States', 'US', 'North America', true),
('USBAL', 'Baltimore', 'Baltimore', 'United States', 'US', 'North America', true),
('CAYVR', 'Vancouver', 'Vancouver', 'Canada', 'CA', 'North America', true),
('BRSSZ', 'Santos', 'Santos', 'Brazil', 'BR', 'South America', true)
ON CONFLICT (port_code) DO NOTHING;

-- Insert standard services
INSERT INTO services (service_name, service_code, category, subcategory, default_unit, description, is_standard) VALUES
('Ocean Freight', 'OCF', 'transport', 'sea', 'per container', 'Main ocean freight charges', true),
('Terminal Handling Charge Origin', 'THC-O', 'handling', 'terminal', 'per container', 'Terminal handling at origin port', true),
('Terminal Handling Charge Destination', 'THC-D', 'handling', 'terminal', 'per container', 'Terminal handling at destination port', true),
('Documentation Fee', 'DOC', 'documentation', 'admin', 'per shipment', 'Documentation and admin fees', true),
('ISPS Security Fee', 'ISPS', 'security', 'port', 'per container', 'International Ship and Port Security fee', true),
('Customs Clearance Export', 'CUS-E', 'customs', 'export', 'per shipment', 'Export customs clearance', true),
('Customs Clearance Import', 'CUS-I', 'customs', 'import', 'per shipment', 'Import customs clearance', true),
('Trucking Pickup', 'TRK-P', 'transport', 'road', 'per container', 'Container pickup trucking', true),
('Trucking Delivery', 'TRK-D', 'transport', 'road', 'per container', 'Container delivery trucking', true),
('Warehouse Handling', 'WHF', 'handling', 'warehouse', 'per ton', 'Warehouse handling charges', true),
('Demurrage', 'DEM', 'charges', 'detention', 'per day', 'Container demurrage charges', false),
('Detention', 'DET', 'charges', 'detention', 'per day', 'Container detention charges', false),
('Bunker Adjustment Factor', 'BAF', 'surcharge', 'fuel', 'per container', 'Fuel surcharge', false),
('Currency Adjustment Factor', 'CAF', 'surcharge', 'currency', 'per container', 'Currency adjustment', false)
ON CONFLICT (service_code) DO NOTHING;

-- Insert document templates
INSERT INTO document_templates (template_name, template_type, template_content) VALUES
('Transport Order', 'transport_order', 
'<html><body>
<h1>TRANSPORT ORDER</h1>
<p><strong>Case Number:</strong> {{case_number}}</p>
<p><strong>Customer:</strong> {{customer_name}}</p>
<p><strong>Reference:</strong> {{customer_reference}}</p>
<p><strong>Service Type:</strong> {{service_type}}</p>
<p><strong>From:</strong> {{origin_port}} to {{destination_port}}</p>
<p><strong>Vessel:</strong> {{vessel_name}}</p>
<p><strong>Carrier:</strong> {{carrier}}</p>
<p><strong>Pickup Date:</strong> {{pickup_date}}</p>
<p><strong>Delivery Date:</strong> {{delivery_date}}</p>
</body></html>'),

('Booking Confirmation', 'booking_confirmation',
'<html><body>
<h1>BOOKING CONFIRMATION</h1>
<p><strong>Booking Number:</strong> {{case_number}}</p>
<p><strong>Customer:</strong> {{customer_name}}</p>
<p><strong>Vessel/Voyage:</strong> {{vessel_name}} / {{voyage}}</p>
<p><strong>Loading Port:</strong> {{loading_port}}</p>
<p><strong>Discharge Port:</strong> {{discharge_port}}</p>
<p><strong>Container Type:</strong> {{container_type}}</p>
<p><strong>Closing Dates:</strong></p>
<ul>
<li>Standard Closing: {{standard_closing}}</li>
<li>VWM Closing: {{vwm_closing}}</li>
<li>CY Closing: {{cy_closing}}</li>
</ul>
</body></html>')
ON CONFLICT DO NOTHING;

-- Enable RLS on all tables
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE ports ENABLE ROW LEVEL SECURITY;
ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE document_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE generated_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE case_status_history ENABLE ROW LEVEL SECURITY;

-- Create policies for customers
CREATE POLICY "Users can manage customers" ON customers FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Anonymous can read customers" ON customers FOR SELECT TO anon USING (is_active = true);
CREATE POLICY "Anonymous can create customers" ON customers FOR INSERT TO anon WITH CHECK (true);

-- Create policies for ports
CREATE POLICY "Users can read ports" ON ports FOR SELECT TO authenticated, anon USING (is_active = true);
CREATE POLICY "Users can manage ports" ON ports FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Create policies for suppliers
CREATE POLICY "Users can manage suppliers" ON suppliers FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Anonymous can read suppliers" ON suppliers FOR SELECT TO anon USING (is_active = true);

-- Create policies for services
CREATE POLICY "Users can manage services" ON services FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Anonymous can read services" ON services FOR SELECT TO anon USING (is_active = true);

-- Create policies for document templates
CREATE POLICY "Users can read templates" ON document_templates FOR SELECT TO authenticated, anon USING (is_active = true);
CREATE POLICY "Users can manage templates" ON document_templates FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Create policies for generated documents
CREATE POLICY "Users can manage generated documents" ON generated_documents FOR ALL TO authenticated, anon USING (true) WITH CHECK (true);

-- Create policies for case status history
CREATE POLICY "Users can read status history" ON case_status_history FOR SELECT TO authenticated, anon USING (true);
CREATE POLICY "Users can create status history" ON case_status_history FOR INSERT TO authenticated, anon WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_customers_company_name ON customers(company_name);
CREATE INDEX IF NOT EXISTS idx_customers_customer_code ON customers(customer_code);
CREATE INDEX IF NOT EXISTS idx_ports_port_code ON ports(port_code);
CREATE INDEX IF NOT EXISTS idx_ports_port_name ON ports(port_name);
CREATE INDEX IF NOT EXISTS idx_suppliers_company_name ON suppliers(company_name);
CREATE INDEX IF NOT EXISTS idx_services_service_name ON services(service_name);
CREATE INDEX IF NOT EXISTS idx_services_category ON services(category);
CREATE INDEX IF NOT EXISTS idx_case_status_history_case_id ON case_status_history(case_id);
CREATE INDEX IF NOT EXISTS idx_generated_documents_case_id ON generated_documents(case_id);