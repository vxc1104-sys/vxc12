/*
  # Create services table for master data

  1. New Tables
    - `services`
      - `id` (uuid, primary key)
      - `name` (text, service name)
      - `category` (text, service category)
      - `default_unit` (text, default unit type)
      - `description` (text, optional description)
      - `is_active` (boolean, default true)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `services` table
    - Add policy for users to read services
    - Add policy for authenticated users to manage services

  3. Sample Data
    - Insert common logistics services
*/

CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL,
  default_unit text DEFAULT 'per container',
  description text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE services ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read services"
  ON services
  FOR SELECT
  TO authenticated, anon
  USING (is_active = true);

CREATE POLICY "Authenticated users can manage services"
  ON services
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Insert sample services
INSERT INTO services (name, category, default_unit, description) VALUES
  ('Ocean Freight', 'transport', 'per container', 'Main ocean transportation cost'),
  ('THC Origin', 'handling', 'per container', 'Terminal Handling Charges at origin port'),
  ('THC Destination', 'handling', 'per container', 'Terminal Handling Charges at destination port'),
  ('Documentation Fee', 'documentation', 'per shipment', 'Document preparation and processing'),
  ('ISPS Fee', 'security', 'per container', 'International Ship and Port Facility Security'),
  ('Customs Clearance', 'customs', 'per shipment', 'Customs clearance and brokerage'),
  ('Trucking Origin', 'transport', 'per container', 'Truck transport at origin'),
  ('Trucking Destination', 'transport', 'per container', 'Truck transport at destination'),
  ('Warehouse Handling', 'handling', 'per ton', 'Warehouse storage and handling'),
  ('Insurance', 'insurance', 'per shipment', 'Cargo insurance coverage'),
  ('Fumigation', 'treatment', 'per container', 'Container fumigation service'),
  ('Seal Fee', 'security', 'per container', 'Container seal cost'),
  ('VGM Fee', 'documentation', 'per container', 'Verified Gross Mass certification'),
  ('AMS Filing', 'documentation', 'per shipment', 'Automated Manifest System filing'),
  ('ENS Filing', 'documentation', 'per shipment', 'Entry Summary Declaration filing')
ON CONFLICT DO NOTHING;